<?php
session_start();
include 'config/database.php';
include 'includes/functions.php';

// Check if user is logged in
if(!isLoggedIn()) {
    redirect('login.php', 'Please login to manage your cart', 'info');
}

// Check if action is set
if(!isset($_POST['action'])) {
    redirect('shop.php');
}

$action = $_POST['action'];
$user_id = $_SESSION['user_id'];

switch($action) {
    case 'add':
        // Add item to cart
        if(!isset($_POST['product_id']) || !is_numeric($_POST['product_id'])) {
            redirect('shop.php', 'Invalid product', 'danger');
        }
        
        $product_id = $_POST['product_id'];
        $quantity = isset($_POST['quantity']) && is_numeric($_POST['quantity']) ? $_POST['quantity'] : 1;
        
        // Check if product exists and has stock
        $product = getProductById($conn, $product_id);
        
        if(!$product) {
            redirect('shop.php', 'Product not found', 'danger');
        }
        
        if($product['stock'] < $quantity) {
            redirect('product.php?id=' . $product_id, 'Not enough stock available', 'warning');
        }
        
        // Add to cart
        if(addToCart($conn, $user_id, $product_id, $quantity)) {
            redirect('cart.php', 'Product added to cart', 'success');
        } else {
            redirect('product.php?id=' . $product_id, 'Failed to add product to cart', 'danger');
        }
        break;
        
    case 'update':
        // Update cart item quantity
        if(!isset($_POST['cart_id']) || !is_numeric($_POST['cart_id']) || !isset($_POST['quantity']) || !is_numeric($_POST['quantity'])) {
            redirect('cart.php', 'Invalid request', 'danger');
        }
        
        $cart_id = $_POST['cart_id'];
        $quantity = $_POST['quantity'];
        
        // Update cart
        if(updateCartItem($conn, $cart_id, $quantity)) {
            redirect('cart.php', 'Cart updated', 'success');
        } else {
            redirect('cart.php', 'Failed to update cart', 'danger');
        }
        break;
        
    case 'remove':
        // Remove item from cart
        if(!isset($_POST['cart_id']) || !is_numeric($_POST['cart_id'])) {
            redirect('cart.php', 'Invalid request', 'danger');
        }
        
        $cart_id = $_POST['cart_id'];
        
        // Remove from cart
        if(removeFromCart($conn, $cart_id)) {
            redirect('cart.php', 'Item removed from cart', 'success');
        } else {
            redirect('cart.php', 'Failed to remove item from cart', 'danger');
        }
        break;
        
    case 'clear':
        // Clear cart
        if(clearCart($conn, $user_id)) {
            redirect('cart.php', 'Cart cleared', 'success');
        } else {
            redirect('cart.php', 'Failed to clear cart', 'danger');
        }
        break;
        
    default:
        redirect('shop.php');
}
?>

