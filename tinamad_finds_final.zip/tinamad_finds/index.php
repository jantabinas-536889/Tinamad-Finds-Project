<?php
session_start();
include 'config/database.php';
include 'includes/functions.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">  
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Tinamad Finds - Thrifted Garments</title>
  <link rel="stylesheet" href="assets/css/style.css">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <style>
    .account-icon {
      position: absolute;
      top: 20px;
      right: 20px;
      font-size: 1.5rem;
      color: white;
      z-index: 10;
    }

    .account-icon a {
      color: white;
      text-decoration: none;
      transition: color 0.3s;
    }

    .account-icon a:hover {
      color: #ddd;
    }

    .hero {
      position: relative;
      padding: 100px 20px;
      text-align: center;
      color: white;
    }

    .hero-content h1 {
      font-size: 3rem;
      margin-bottom: 1rem;
    }

    .hero-content p {
      font-size: 1.2rem;
      margin-bottom: 2rem;
      max-width: 600px;
      margin-left: auto;
      margin-right: auto;
    }

    .btn {
      background-color: #6C4AB6;
      color: white;
      padding: 12px 25px;
      border: none;
      border-radius: 5px;
      text-decoration: none;
      font-weight: 600;
      transition: background 0.3s;
    }

    .btn:hover {
      background-color: #8D72E1;
    }
  </style>
</head>
<body>
  <?php include 'includes/header.php'; ?>

  <!-- My Account Icon -->
  <div class="account-icon">
    <a href="account.php" title="My Account">
      <i class="fas fa-user-circle"></i>
    </a>
  </div>


  <main>
    <section class="hero full-width" style="background-image: linear-gradient(rgba(0, 0, 0, 0.833), rgba(0, 0, 0, 0.4)), url('thrift4.jpg'); background-size: cover; background-position: center;">
      <div class="hero-content">
        <h1>Welcome to Tinamad Finds</h1>
        <p>
          Too lazy to thrift? Same. That’s why we did it for you. Vintage ‘fits, secondhand steals, 
          and hidden gems all served with zero effort on your part. Lazy never looked so good.
        </p>
        <a href="shop.php" class="btn">Shop Now</a>
      </div>
    </section>
  </main>

  <?php include 'includes/footer.php'; ?>
  <script src="assets/js/main.js"></script>
</body>
</html>
