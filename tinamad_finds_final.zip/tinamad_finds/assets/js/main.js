document.addEventListener("DOMContentLoaded", () => {
  // Mobile menu toggle
  const mobileMenuToggle = document.querySelector(".mobile-menu-toggle")
  const mobileMenu = document.querySelector(".mobile-menu")

  if (mobileMenuToggle && mobileMenu) {
    mobileMenuToggle.addEventListener("click", () => {
      mobileMenu.classList.toggle("active")
    })
  }

  // Quantity input controls
  const quantityInputs = document.querySelectorAll(".quantity-input")

  quantityInputs.forEach((input) => {
    const decrementBtn = input.parentElement.querySelector(".decrement")
    const incrementBtn = input.parentElement.querySelector(".increment")

    if (decrementBtn) {
      decrementBtn.addEventListener("click", () => {
        const value = Number.parseInt(input.value)
        if (value > 1) {
          input.value = value - 1
          // Trigger change event for form updates
          const event = new Event("change")
          input.dispatchEvent(event)
        }
      })
    }

    if (incrementBtn) {
      incrementBtn.addEventListener("click", () => {
        const value = Number.parseInt(input.value)
        const max = Number.parseInt(input.getAttribute("max") || 99)
        if (value < max) {
          input.value = value + 1
          // Trigger change event for form updates
          const event = new Event("change")
          input.dispatchEvent(event)
        }
      })
    }
  })

  // Product image gallery
  const mainImage = document.querySelector(".product-main-image img")
  const thumbnails = document.querySelectorAll(".product-thumbnails img")

  if (mainImage && thumbnails.length > 0) {
    thumbnails.forEach((thumbnail) => {
      thumbnail.addEventListener("click", function () {
        mainImage.src = this.src
        thumbnails.forEach((t) => t.classList.remove("active"))
        this.classList.add("active")
      })
    })
  }

  // Auto-update cart on quantity change
  const cartQuantityInputs = document.querySelectorAll(".cart-quantity")

  cartQuantityInputs.forEach((input) => {
    input.addEventListener("change", function () {
      const form = this.closest("form")
      if (form) {
        form.submit()
      }
    })
  })

  // Dismiss alerts
  const alerts = document.querySelectorAll(".alert")

  alerts.forEach((alert) => {
    setTimeout(() => {
      alert.style.opacity = "0"
      setTimeout(() => {
        alert.style.display = "none"
      }, 500)
    }, 5000)
  })
})

