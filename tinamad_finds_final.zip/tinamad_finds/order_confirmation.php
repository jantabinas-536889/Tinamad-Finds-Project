<?php
session_start();
include 'config/database.php';
include 'includes/functions.php';

// Check if user is logged in
if(!isLoggedIn()) {
    redirect('login.php', 'Please login to view order details', 'info');
}

// Check if order ID is provided
if(!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    redirect('account.php', 'Invalid order ID', 'danger');
}

$order_id = $_GET['id'];
$order = getOrderById($conn, $order_id);

// Check if order exists and belongs to the user
if(!$order || $order['user_id'] != $_SESSION['user_id']) {
    redirect('account.php', 'Order not found', 'danger');
}

// Get order items
$order_items = getOrderItems($conn, $order_id);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Confirmation - Tinamad Finds</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .confirmation-container {
            max-width: 800px;
            margin: 40px auto;
            background-color: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        
        .confirmation-header {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .confirmation-header i {
            font-size: 64px;
            color: #4CAF50;
            margin-bottom: 20px;
        }
        
        .confirmation-header h2 {
            font-size: 24px;
            margin-bottom: 10px;
        }
        
        .order-details {
            margin-bottom: 30px;
        }
        
        .order-details h3 {
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 1px solid #eee;
        }
        
        .detail-row {
            display: flex;
            margin-bottom: 10px;
        }
        
        .detail-label {
            font-weight: 700;
            width: 150px;
        }
        
        .order-items {
            margin-bottom: 30px;
        }
        
        .order-items h3 {
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 1px solid #eee;
        }
        
        .order-item {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
            padding-bottom: 15px;
            border-bottom: 1px solid #eee;
        }
        
        .order-item:last-child {
            border-bottom: none;
        }
        
        .order-item-image {
            width: 60px;
            height: 60px;
            border-radius: 4px;
            overflow: hidden;
            margin-right: 15px;
        }
        
        .order-item-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .order-item-details {
            flex: 1;
        }
        
        .order-item-name {
            font-weight: 500;
            margin-bottom: 5px;
        }
        
        .order-item-price {
            color: #666;
            font-size: 14px;
        }
        
        .order-item-quantity {
            margin-left: auto;
            color: #666;
        }
        
        .order-total {
            text-align: right;
            font-size: 20px;
            font-weight: 700;
            margin-top: 20px;
        }
        
        .shipping-info {
            margin-bottom: 30px;
        }
        
        .shipping-info h3 {
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 1px solid #eee;
        }
        
        .shipping-address {
            white-space: pre-line;
            line-height: 1.6;
        }
        
        .confirmation-actions {
            display: flex;
            justify-content: space-between;
            margin-top: 30px;
        }
    </style>
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <main class="container">
        <div class="confirmation-container">
            <div class="confirmation-header">
                <i class="fas fa-check-circle"></i>
                <h2>Thank You for Your Order!</h2>
                <p>Your order has been placed successfully.</p>
            </div>
            
            <div class="order-details">
                <h3>Order Details</h3>
                
                <div class="detail-row">
                    <div class="detail-label">Order Number:</div>
                    <div class="detail-value">#<?php echo $order['id']; ?></div>
                </div>
                
                <div class="detail-row">
                    <div class="detail-label">Order Date:</div>
                    <div class="detail-value"><?php echo date('F j, Y', strtotime($order['created_at'])); ?></div>
                </div>
                
                <div class="detail-row">
                    <div class="detail-label">Order Status:</div>
                    <div class="detail-value"><?php echo ucfirst($order['status']); ?></div>
                </div>
                
                <div class="detail-row">
                    <div class="detail-label">Payment Status:</div>
                    <div class="detail-value"><?php echo ucfirst($order['payment_status']); ?></div>
                </div>
            </div>
            
            <div class="order-items">
                <h3>Order Items</h3>
                
                <?php foreach($order_items as $item): ?>
                    <div class="order-item">
                        <div class="order-item-image">
                            <img src="assets/images/products/<?php echo htmlspecialchars($item['image']); ?>" alt="<?php echo htmlspecialchars($item['name']); ?>">
                        </div>
                        
                        <div class="order-item-details">
                            <div class="order-item-name"><?php echo htmlspecialchars($item['name']); ?></div>
                            <div class="order-item-price">₱<?php echo number_format($item['price'], 2); ?></div>
                        </div>
                        
                        <div class="order-item-quantity">
                            x<?php echo $item['quantity']; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
                
                <div class="order-total">
                    Total: ₱<?php echo number_format($order['total_amount'], 2); ?>
                </div>
            </div>
            
            <div class="shipping-info">
                <h3>Shipping Information</h3>
                
                <div class="shipping-address">
                    <?php echo nl2br(htmlspecialchars($order['shipping_address'])); ?>
                </div>
            </div>
            
            <div class="confirmation-actions">
                <a href="shop.php" class="btn btn-outline">Continue Shopping</a>
                <a href="orders.php" class="btn">View All Orders</a>
            </div>
        </div>
    </main>
    
    <?php include 'includes/footer.php'; ?>
    <script src="assets/js/main.js"></script>
</body>
</html>

