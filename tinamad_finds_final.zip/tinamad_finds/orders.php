<?php
session_start();
include 'config/database.php';
include 'includes/functions.php';

// Check if user is logged in
if(!isLoggedIn()) {
  redirect('login.php', 'Please login to view your orders', 'info');
}

// Get user orders
$orders = getUserOrders($conn, $_SESSION['user_id']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>My Orders - Tinamad Finds</title>
  <link rel="stylesheet" href="assets/css/style.css">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <style>
    .account-container {
      display: grid;
      grid-template-columns: 250px 1fr;
      gap: 30px;
      margin: 40px 0;
    }
    
    .account-sidebar {
      background-color: #fff;
      padding: 20px;
      border-radius: 8px;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
      height: fit-content;
    }
    
    .account-sidebar h3 {
      margin-bottom: 20px;
      padding-bottom: 10px;
      border-bottom: 1px solid #eee;
    }
    
    .account-menu {
      list-style: none;
      padding: 0;
    }
    
    .account-menu li {
      margin-bottom: 10px;
    }
    
    .account-menu li a {
      display: flex;
      align-items: center;
      padding: 10px;
      border-radius: 4px;
      transition: background-color 0.3s;
    }
    
    .account-menu li a:hover,
    .account-menu li a.active {
      background-color: #f5f5f5;
      color: #4a00e0;
    }
    
    .account-menu li a i {
      margin-right: 10px;
      width: 20px;
      text-align: center;
    }
    
    .account-content {
      background-color: #fff;
      padding: 30px;
      border-radius: 8px;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    }
    
    .account-content h2 {
      margin-bottom: 30px;
      padding-bottom: 15px;
      border-bottom: 1px solid #eee;
    }
    
    .orders-table {
      width: 100%;
      border-collapse: collapse;
    }
    
    .orders-table th,
    .orders-table td {
      padding: 12px 15px;
      text-align: left;
      border-bottom: 1px solid #eee;
    }
    
    .orders-table th {
      background-color: #f9f9f9;
      font-weight: 600;
    }
    
    .status-badge {
      display: inline-block;
      padding: 5px 10px;
      border-radius: 20px;
      font-size: 12px;
      font-weight: 700;
      text-transform: uppercase;
    }
    
    .status-pending {
      background-color: #f39c12;
      color: #fff;
    }
    
    .status-processing {
      background-color: #3498db;
      color: #fff;
    }
    
    .status-shipped {
      background-color: #2ecc71;
      color: #fff;
    }
    
    .status-delivered {
      background-color: #27ae60;
      color: #fff;
    }
    
    .status-cancelled {
      background-color: #e74c3c;
      color: #fff;
    }
    
    .empty-orders {
      text-align: center;
      padding: 50px 0;
    }
    
    .empty-orders i {
      font-size: 48px;
      color: #ddd;
      margin-bottom: 20px;
    }
    
    .empty-orders h3 {
      margin-bottom: 20px;
    }
    
    @media (max-width: 768px) {
      .account-container {
        grid-template-columns: 1fr;
      }
      
      .orders-table thead {
        display: none;
      }
      
      .orders-table tbody, 
      .orders-table tr, 
      .orders-table td {
        display: block;
        width: 100%;
      }
      
      .orders-table tr {
        margin-bottom: 20px;
        border: 1px solid #eee;
        border-radius: 8px;
        overflow: hidden;
      }
      
      .orders-table td {
        text-align: right;
        padding: 10px;
        position: relative;
        border-bottom: 1px solid #eee;
      }
      
      .orders-table td:last-child {
        border-bottom: none;
      }
      
      .orders-table td::before {
        content: attr(data-label);
        position: absolute;
        left: 10px;
        top: 10px;
        font-weight: 700;
      }
    }
  </style>
</head>
<body>
  <?php include 'includes/header.php'; ?>
  
  
  <main class="container">
    <div class="account-container">
      <div class="account-sidebar">
        <h3>My Account</h3>
        
        <ul class="account-menu">
          <li><a href="account.php"><i class="fas fa-user"></i> Account Details</a></li>
          <li><a href="orders.php" class="active"><i class="fas fa-shopping-bag"></i> My Orders</a></li>
          <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
        </ul>
      </div>
      
      <div class="account-content">
        <h2>My Orders</h2>
        
        <?php if(empty($orders)): ?>
          <div class="empty-orders">
            <i class="fas fa-shopping-bag"></i>
            <h3>No Orders Found</h3>
            <p>You haven't placed any orders yet.</p>
            <a href="shop.php" class="btn">Start Shopping</a>
          </div>
        <?php else: ?>
          <table class="orders-table">
            <thead>
              <tr>
                <th>Order ID</th>
                <th>Date</th>
                <th>Total</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach($orders as $order): ?>
                <tr>
                  <td data-label="Order ID">#<?php echo $order['id']; ?></td>
                  <td data-label="Date"><?php echo date('M d, Y', strtotime($order['created_at'])); ?></td>
                  <td data-label="Total">₱<?php echo number_format($order['total_amount'], 2); ?></td>
                  <td data-label="Status">
                    <span class="status-badge status-<?php echo $order['status']; ?>">
                      <?php echo ucfirst($order['status']); ?>
                    </span>
                  </td>
                  <td data-label="Action">
                    <a href="order_details.php?id=<?php echo $order['id']; ?>" class="btn btn-sm">View</a>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        <?php endif; ?>
      </div>
    </div>
  </main>
  
  <?php include 'includes/footer.php'; ?>
  <script src="assets/js/main.js"></script>
</body>
</html>

