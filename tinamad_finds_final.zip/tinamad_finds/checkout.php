<?php
session_start();
include 'config/database.php';
include 'includes/functions.php';

// Check if user is logged in
if(!isLoggedIn()) {
    redirect('login.php', 'Please login to checkout', 'info');
}

// Get cart items
$cart_items = getCartItems($conn, $_SESSION['user_id']);
$cart_total = getCartTotal($conn, $_SESSION['user_id']);

// Check if cart is empty
if(empty($cart_items)) {
    redirect('cart.php', 'Your cart is empty', 'info');
}

// Get user details
$user = getUserById($conn, $_SESSION['user_id']);

// Process checkout form
if($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate shipping address
    $first_name = trim($_POST['first_name']);
    $last_name = trim($_POST['last_name']);
    $address = trim($_POST['address']);
    $city = trim($_POST['city']);
    $postal_code = trim($_POST['postal_code']);
    $country = trim($_POST['country']);
    $phone = trim($_POST['phone']);
    
    $errors = [];
    
    if(empty($first_name) || empty($last_name) || empty($address) || empty($city) || empty($postal_code) || empty($country) || empty($phone)) {
        $errors[] = 'All fields are required';
    }
    
    if(empty($errors)) {
        // Update user details
        $sql = "UPDATE users SET first_name = :first_name, last_name = :last_name, address = :address, city = :city, postal_code = :postal_code, country = :country, phone = :phone WHERE id = :id";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':first_name', $first_name);
        $stmt->bindParam(':last_name', $last_name);
        $stmt->bindParam(':address', $address);
        $stmt->bindParam(':city', $city);
        $stmt->bindParam(':postal_code', $postal_code);
        $stmt->bindParam(':country', $country);
        $stmt->bindParam(':phone', $phone);
        $stmt->bindParam(':id', $_SESSION['user_id'], PDO::PARAM_INT);
        $stmt->execute();
        
        // Create shipping address string
        $shipping_address = "$first_name $last_name\n$address\n$city, $postal_code\n$country\n$phone";
        
        // Use same billing address
        $billing_address = $shipping_address;
        
        // Create order
        $order_id = createOrder($conn, $_SESSION['user_id'], $cart_total, $shipping_address, $billing_address);
        
        if($order_id) {
            // Add order items
            addOrderItems($conn, $order_id, $cart_items);
            
            // Clear cart
            clearCart($conn, $_SESSION['user_id']);
            
            // Redirect to order confirmation
            redirect('order_confirmation.php?id=' . $order_id, 'Order placed successfully!', 'success');
        } else {
            $errors[] = 'Failed to create order. Please try again.';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout - Nova Wear</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .checkout-container {
            display: grid;
            grid-template-columns: 1fr 400px;
            gap: 30px;
            margin: 40px 0;
        }
        
        .checkout-form {
            background-color: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        
        .checkout-form h2 {
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 1px solid #eee;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: 500;
        }
        
        .form-group input,
        .form-group select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }
        
        .order-summary {
            background-color: #f9f9f9;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            align-self: start;
        }
        
        .order-summary h2 {
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 1px solid #eee;
        }
        
        .order-items {
            margin-bottom: 20px;
        }
        
        .order-item {
            display: flex;
            margin-bottom: 15px;
            padding-bottom: 15px;
            border-bottom: 1px solid #eee;
        }
        
        .order-item:last-child {
            border-bottom: none;
        }
        
        .order-item-image {
            width: 60px;
            height: 60px;
            border-radius: 4px;
            overflow: hidden;
            margin-right: 15px;
        }
        
        .order-item-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .order-item-details {
            flex: 1;
        }
        
        .order-item-name {
            font-weight: 500;
            margin-bottom: 5px;
        }
        
        .order-item-price {
            color: #666;
            font-size: 14px;
        }
        
        .order-item-quantity {
            margin-left: auto;
            color: #666;
        }
        
        .summary-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
        }
        
        .summary-row.total {
            font-size: 20px;
            font-weight: 700;
            border-top: 1px solid #ddd;
            padding-top: 10px;
            margin-top: 10px;
        }
        
        .payment-methods {
            margin-top: 30px;
        }
        
        .payment-methods h3 {
            margin-bottom: 15px;
        }
        
        .payment-method {
            margin-bottom: 10px;
        }
        
        .payment-method label {
            display: flex;
            align-items: center;
            cursor: pointer;
        }
        
        .payment-method input {
            margin-right: 10px;
        }
        
        .error-list {
            background-color: #f8d7da;
            color: #721c24;
            padding: 15px;
            border-radius: 4px;
            margin-bottom: 20px;
        }
        
        .error-list ul {
            margin-left: 20px;
            list-style-type: disc;
        }
        
        @media (max-width: 992px) {
            .checkout-container {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <main class="container">
        <h1 class="page-title">Checkout</h1>
        
        <?php if(!empty($errors)): ?>
            <div class="error-list">
                <ul>
                    <?php foreach($errors as $error): ?>
                        <li><?php echo $error; ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>
        
        <div class="checkout-container">
            <div class="checkout-form">
                <h2>Shipping Information</h2>
                
                <form action="checkout.php" method="post">
                    <div class="form-row">
                        <div class="form-group">
                            <label for="first_name">First Name</label>
                            <input type="text" id="first_name" name="first_name" value="<?php echo $user['first_name'] ?? ''; ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="last_name">Last Name</label>
                            <input type="text" id="last_name" name="last_name" value="<?php echo $user['last_name'] ?? ''; ?>" required>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="address">Address</label>
                        <input type="text" id="address" name="address" value="<?php echo $user['address'] ?? ''; ?>" required>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="city">City</label>
                            <input type="text" id="city" name="city" value="<?php echo $user['city'] ?? ''; ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="postal_code">Postal Code</label>
                            <input type="text" id="postal_code" name="postal_code" value="<?php echo $user['postal_code'] ?? ''; ?>" required>
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="country">Country</label>
                            <select id="country" name="country" required>
                                <option value="">Select Country</option>
                                <option value="USA" <?php echo ($user['country'] ?? '') === 'USA' ? 'selected' : ''; ?>>United States</option>
                                <option value="Canada" <?php echo ($user['country'] ?? '') === 'Canada' ? 'selected' : ''; ?>>Canada</option>
                                <option value="UK" <?php echo ($user['country'] ?? '') === 'UK' ? 'selected' : ''; ?>>United Kingdom</option>
                                <option value="Philippines" <?php echo ($user['country'] ?? '') === 'Philippines' ? 'selected' : ''; ?>>Philippines</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="phone">Phone</label>
                            <input type="tel" id="phone" name="phone" value="<?php echo $user['phone'] ?? ''; ?>" required>
                        </div>
                    </div>
                    
                    <div class="payment-methods">
                        <h3>Payment Method</h3>
                        
                        <div class="payment-method">
                            <label>
                                <input type="radio" name="payment_method" value="credit_card" checked>
                                Credit Card
                            </label>
                        </div>
                        
                        <div class="payment-method">
                            <label>
                                <input type="radio" name="payment_method" value="cash">
                                Cash on Delivery
                            </label>
                        </div>
                    </div>
                    
                    <button type="submit" class="btn" style="width: 100%; margin-top: 20px;">Place Order</button>
                </form>
            </div>
            
            <div class="order-summary">
                <h2>Order Summary</h2>
                
                <div class="order-items">
                    <?php foreach($cart_items as $item): ?>
                        <div class="order-item">
                            <div class="order-item-image">
                                <img src="assets/images/products/<?php echo htmlspecialchars($item['image']); ?>" alt="<?php echo htmlspecialchars($item['name']); ?>">
                            </div>
                            
                            <div class="order-item-details">
                                <div class="order-item-name"><?php echo htmlspecialchars($item['name']); ?></div>
                                <div class="order-item-price">
                                    <?php if($item['sale_price']): ?>
                                        ₱<?php echo number_format($item['sale_price'], 2); ?>
                                    <?php else: ?>
                                        ₱<?php echo number_format($item['price'], 2); ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                            
                            <div class="order-item-quantity">
                                x<?php echo $item['quantity']; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                
                <div class="summary-row">
                    <span>Subtotal</span>
                    <span>₱<?php echo number_format($cart_total, 2); ?></span>
                </div>
                
                <div class="summary-row">
                    <span>Shipping</span>
                    <span>Free</span>
                </div>
                
                <div class="summary-row total">
                    <span>Total</span>
                    <span>₱<?php echo number_format($cart_total, 2); ?></span>
                </div>
            </div>
        </div>
    </main>
    
    <?php include 'includes/footer.php'; ?>
    <script src="assets/js/main.js"></script>
</body>
</html>

