<?php
session_start();
include 'config/database.php';
include 'includes/functions.php';

// Check if user is logged in
if(!isLoggedIn()) {
    redirect('login.php', 'Please login to view your cart', 'info');
}

// Get cart items
$cart_items = getCartItems($conn, $_SESSION['user_id']);
$cart_total = getCartTotal($conn, $_SESSION['user_id']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart - Nova Wear</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .cart-container {
            margin: 40px 0;
        }
        
        .cart-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
        }
        
        .cart-table th {
            text-align: left;
            padding: 15px;
            background-color: #f5f5f5;
            border-bottom: 1px solid #ddd;
        }
        
        .cart-table td {
            padding: 15px;
            border-bottom: 1px solid #ddd;
        }
        
        .cart-product {
            display: flex;
            align-items: center;
        }
        
        .cart-product img {
            width: 80px;
            height: 80px;
            object-fit: cover;
            margin-right: 15px;
            border-radius: 4px;
        }
        
        .cart-product-info h3 {
            margin-bottom: 5px;
        }
        
        .cart-quantity {
            width: 60px;
            padding: 5px;
            text-align: center;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        
        .cart-remove {
            color: #e53935;
            cursor: pointer;
        }
        
        .cart-summary {
            background-color: #f9f9f9;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 30px;
        }
        
        .cart-summary h2 {
            margin-bottom: 20px;
        }
        
        .summary-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
        }
        
        .summary-row.total {
            font-size: 20px;
            font-weight: 700;
            border-top: 1px solid #ddd;
            padding-top: 10px;
            margin-top: 10px;
        }
        
        .cart-actions {
            display: flex;
            justify-content: space-between;
        }
        
        .empty-cart {
            text-align: center;
            padding: 50px 0;
        }
        
        .empty-cart i {
            font-size: 48px;
            color: #ddd;
            margin-bottom: 20px;
        }
        
        .empty-cart h2 {
            margin-bottom: 20px;
        }
        
        @media (max-width: 768px) {
            .cart-table thead {
                display: none;
            }
            
            .cart-table tbody, .cart-table tr, .cart-table td {
                display: block;
                width: 100%;
            }
            
            .cart-table tr {
                margin-bottom: 20px;
                border: 1px solid #ddd;
                border-radius: 8px;
                overflow: hidden;
            }
            
            .cart-table td {
                text-align: right;
                padding: 10px;
                position: relative;
                border-bottom: 1px solid #eee;
            }
            
            .cart-table td:last-child {
                border-bottom: none;
            }
            
            .cart-table td::before {
                content: attr(data-label);
                position: absolute;
                left: 10px;
                top: 10px;
                font-weight: 700;
            }
            
            .cart-product {
                justify-content: flex-end;
            }
        }
    </style>
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <main class="container">
        <h1 class="page-title">Shopping Cart</h1>
        
        <div class="cart-container">
            <?php if(empty($cart_items)): ?>
                <div class="empty-cart">
                    <i class="fas fa-shopping-cart"></i>
                    <h2>Your cart is empty</h2>
                    <p>Looks like you haven't added any products to your cart yet.</p>
                    <a href="shop.php" class="btn">Continue Shopping</a>
                </div>
            <?php else: ?>
                <div class="cart-content">
                    <table class="cart-table">
                        <thead>
                            <tr>
                                <th>Product</th>
                                <th>Price</th>
                                <th>Quantity</th>
                                <th>Total</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($cart_items as $item): ?>
                                <tr>
                                    <td data-label="Product">
                                        <div class="cart-product">
                                            <img src="assets/images/products/<?php echo htmlspecialchars($item['image']); ?>" alt="<?php echo htmlspecialchars($item['name']); ?>">
                                            <div class="cart-product-info">
                                                <h3><?php echo htmlspecialchars($item['name']); ?></h3>
                                            </div>
                                        </div>
                                    </td>
                                    <td data-label="Price">
                                        <?php if($item['sale_price']): ?>
                                            ₱<?php echo number_format($item['sale_price'], 2); ?>
                                        <?php else: ?>
                                            ₱<?php echo number_format($item['price'], 2); ?>
                                        <?php endif; ?>
                                    </td>
                                    <td data-label="Quantity">
                                        <form action="cart_actions.php" method="post">
                                            <input type="hidden" name="action" value="update">
                                            <input type="hidden" name="cart_id" value="<?php echo $item['cart_id']; ?>">
                                            <input type="number" name="quantity" value="<?php echo $item['quantity']; ?>" min="1" max="<?php echo $item['stock']; ?>" class="cart-quantity">
                                        </form>
                                    </td>
                                    <td data-label="Total">
                                        <?php
                                        $price = $item['sale_price'] ? $item['sale_price'] : $item['price'];
                                        $total = $price * $item['quantity'];
                                        echo '₱' . number_format($total, 2);
                                        ?>
                                    </td>
                                    <td data-label="Action">
                                        <form action="cart_actions.php" method="post">
                                            <input type="hidden" name="action" value="remove">
                                            <input type="hidden" name="cart_id" value="<?php echo $item['cart_id']; ?>">
                                            <button type="submit" class="cart-remove">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    
                    <div class="cart-summary">
                        <h2>Order Summary</h2>
                        
                        <div class="summary-row">
                            <span>Subtotal</span>
                            <span>₱<?php echo number_format($cart_total, 2); ?></span>
                        </div>
                        
                        <div class="summary-row">
                            <span>Shipping</span>
                            <span>Free</span>
                        </div>
                        
                        <div class="summary-row total">
                            <span>Total</span>
                            <span>₱<?php echo number_format($cart_total, 2); ?></span>
                        </div>
                    </div>
                    
                    <div class="cart-actions">
                        <a href="shop.php" class="btn btn-outline">Continue Shopping</a>
                        <a href="checkout.php" class="btn">Proceed to Checkout</a>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </main>
    
    <?php include 'includes/footer.php'; ?>
    <script src="assets/js/main.js"></script>
</body>
</html>
