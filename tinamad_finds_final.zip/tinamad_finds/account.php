<?php
session_start();
include 'config/database.php';
include 'includes/functions.php';

// Check if user is logged in
if(!isLoggedIn()) {
  redirect('login.php', 'Please login to view your account', 'info');
}

// Get user details
$user = getUserById($conn, $_SESSION['user_id']);

$success = false;
$errors = [];

// Process form submission
if($_SERVER['REQUEST_METHOD'] === 'POST') {
  $first_name = trim($_POST['first_name']);
  $last_name = trim($_POST['last_name']);
  $email = trim($_POST['email']);
  $address = trim($_POST['address']);
  $city = trim($_POST['city']);
  $postal_code = trim($_POST['postal_code']);
  $country = trim($_POST['country']);
  $phone = trim($_POST['phone']);
  $current_password = $_POST['current_password'];
  $new_password = $_POST['new_password'];
  $confirm_password = $_POST['confirm_password'];
  
  // Validate email
  if(empty($email)) {
    $errors[] = 'Email is required';
  } elseif(!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors[] = 'Please enter a valid email address';
  } elseif($email !== $user['email']) {
    // Check if email already exists
    $existing_email = getUserByEmail($conn, $email);
    if($existing_email) {
      $errors[] = 'Email already exists';
    }
  }
  
  // Validate password change if requested
  if(!empty($current_password) || !empty($new_password) || !empty($confirm_password)) {
    if(empty($current_password)) {
      $errors[] = 'Current password is required to change password';
    } elseif(!password_verify($current_password, $user['password'])) {
      $errors[] = 'Current password is incorrect';
    }
    
    if(empty($new_password)) {
      $errors[] = 'New password is required';
    } elseif(strlen($new_password) < 6) {
      $errors[] = 'New password must be at least 6 characters';
    }
    
    if($new_password !== $confirm_password) {
      $errors[] = 'New passwords do not match';
    }
  }
  
  // If no errors, update user
  if(empty($errors)) {
    // Prepare SQL statement
    $sql = "UPDATE users SET 
            email = :email,
            first_name = :first_name,
            last_name = :last_name,
            address = :address,
            city = :city,
            postal_code = :postal_code,
            country = :country,
            phone = :phone";
    
    // Add password update if requested
    if(!empty($new_password)) {
      $sql .= ", password = :password";
    }
    
    $sql .= " WHERE id = :id";
    
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':first_name', $first_name);
    $stmt->bindParam(':last_name', $last_name);
    $stmt->bindParam(':address', $address);
    $stmt->bindParam(':city', $city);
    $stmt->bindParam(':postal_code', $postal_code);
    $stmt->bindParam(':country', $country);
    $stmt->bindParam(':phone', $phone);
    $stmt->bindParam(':id', $_SESSION['user_id'], PDO::PARAM_INT);
    
    // Bind password if updating
    if(!empty($new_password)) {
      $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
      $stmt->bindParam(':password', $hashed_password);
    }
    
    if($stmt->execute()) {
      $success = true;
      // Refresh user data
      $user = getUserById($conn, $_SESSION['user_id']);
    } else {
      $errors[] = 'Failed to update account. Please try again.';
    }
  }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>My Account - Tinamad Finds</title>
  <link rel="stylesheet" href="assets/css/style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    .account-container {
      display: grid;
      grid-template-columns: 250px 1fr;
      gap: 30px;
      margin: 40px 0;
    }
    
    .account-sidebar {
      background-color: #fff;
      padding: 20px;
      border-radius: 8px;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
      height: fit-content;
    }
    
    .account-sidebar h3 {
      margin-bottom: 20px;
      padding-bottom: 10px;
      border-bottom: 1px solid #eee;
    }
    
    .account-menu {
      list-style: none;
      padding: 0;
    }
    
    .account-menu li {
      margin-bottom: 10px;
    }
    
    .account-menu li a {
      display: flex;
      align-items: center;
      padding: 10px;
      border-radius: 4px;
      transition: background-color 0.3s;
    }
    
    .account-menu li a:hover,
    .account-menu li a.active {
      background-color: #f5f5f5;
      color: #4a00e0;
    }
    
    .account-menu li a i {
      margin-right: 10px;
      width: 20px;
      text-align: center;
    }
    
    .account-content {
      background-color: #fff;
      padding: 30px;
      border-radius: 8px;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    }
    
    .account-content h2 {
      margin-bottom: 30px;
      padding-bottom: 15px;
      border-bottom: 1px solid #eee;
    }
    
    .form-group {
      margin-bottom: 20px;
    }
    
    .form-group label {
      display: block;
      margin-bottom: 5px;
      font-weight: 500;
    }
    
    .form-group input {
      width: 100%;
      padding: 10px;
      border: 1px solid #ddd;
      border-radius: 4px;
    }
    
    .form-row {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 20px;
    }
    
    .form-section {
      margin-bottom: 30px;
    }
    
    .form-section h3 {
      margin-bottom: 20px;
      font-size: 18px;
      color: #4a00e0;
    }
    
    .success-message {
      background-color: #d4edda;
      color: #155724;
      padding: 15px;
      border-radius: 4px;
      margin-bottom: 20px;
    }
    
    .error-list {
      background-color: #f8d7da;
      color: #721c24;
      padding: 15px;
      border-radius: 4px;
      margin-bottom: 20px;
    }
    
    .error-list ul {
      margin-left: 20px;
      list-style-type: disc;
    }
    
    @media (max-width: 768px) {
      .account-container {
        grid-template-columns: 1fr;
      }
      
      .form-row {
        grid-template-columns: 1fr;
        gap: 0;
      }
    }
  </style>
</head>
<body>
  <?php include 'includes/header.php'; ?>
  
  <main class="container">
    <div class="account-container">
      <div class="account-sidebar">
        <h3>My Account</h3>
        
        <ul class="account-menu">
          <li><a href="account.php" class="active"><i class="fas fa-user"></i> Account Details</a></li>
          <li><a href="orders.php"><i class="fas fa-shopping-bag"></i> My Orders</a></li>
          <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
        </ul>
      </div>
      
      <div class="account-content">
        <h2>Account Details</h2>
        
        <?php if($success): ?>
          <div class="success-message">
            Your account information has been updated successfully.
          </div>
        <?php endif; ?>
        
        <?php if(!empty($errors)): ?>
          <div class="error-list">
            <ul>
              <?php foreach($errors as $error): ?>
                <li><?php echo $error; ?></li>
              <?php endforeach; ?>
            </ul>
          </div>
        <?php endif; ?>
        
        <form action="account.php" method="post">
          <div class="form-section">
            <h3>Personal Information</h3>
            
            <div class="form-row">
              <div class="form-group">
                <label for="first_name">First Name</label>
                <input type="text" id="first_name" name="first_name" value="<?php echo htmlspecialchars($user['first_name'] ?? ''); ?>">
              </div>
              
              <div class="form-group">
                <label for="last_name">Last Name</label>
                <input type="text" id="last_name" name="last_name" value="<?php echo htmlspecialchars($user['last_name'] ?? ''); ?>">
              </div>
            </div>
            
            <div class="form-group">
              <label for="email">Email Address</label>
              <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
            </div>
            
            <div class="form-group">
              <label for="phone">Phone Number</label>
              <input type="tel" id="phone" name="phone" value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>">
            </div>
          </div>
          
          <div class="form-section">
            <h3>Address Information</h3>
            
            <div class="form-group">
              <label for="address">Address</label>
              <input type="text" id="address" name="address" value="<?php echo htmlspecialchars($user['address'] ?? ''); ?>">
            </div>
            
            <div class="form-row">
              <div class="form-group">
                <label for="city">City</label>
                <input type="text" id="city" name="city" value="<?php echo htmlspecialchars($user['city'] ?? ''); ?>">
              </div>
              
              <div class="form-group">
                <label for="postal_code">Postal Code</label>
                <input type="text" id="postal_code" name="postal_code" value="<?php echo htmlspecialchars($user['postal_code'] ?? ''); ?>">
              </div>
            </div>
            
            <div class="form-group">
              <label for="country">Country</label>
              <input type="text" id="country" name="country" value="<?php echo htmlspecialchars($user['country'] ?? ''); ?>">
            </div>
          </div>
          
          <div class="form-section">
            <h3>Change Password</h3>
            <p style="margin-bottom: 15px; color: #666;">Leave blank to keep your current password</p>
            
            <div class="form-group">
              <label for="current_password">Current Password</label>
              <input type="password" id="current_password" name="current_password">
            </div>
            
            <div class="form-row">
              <div class="form-group">
                <label for="new_password">New Password</label>
                <input type="password" id="new_password" name="new_password">
              </div>
              
              <div class="form-group">
                <label for="confirm_password">Confirm New Password</label>
                <input type="password" id="confirm_password" name="confirm_password">
              </div>
            </div>
          </div>
          
          <button type="submit" class="btn">Save Changes</button>
        </form>
      </div>
    </div>
  </main>
  
  <?php include 'includes/footer.php'; ?>
  <script src="assets/js/main.js"></script>
</body>
</html>

