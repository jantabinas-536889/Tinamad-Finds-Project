<?php
session_start();
include 'config/database.php';
include 'includes/functions.php';

// Check if user is logged in
if(!isLoggedIn()) {
  redirect('login.php', 'Please login to view order details', 'info');
}

// Check if order ID is provided
if(!isset($_GET['id']) || !is_numeric($_GET['id'])) {
  redirect('orders.php', 'Invalid order ID', 'danger');
}

$order_id = $_GET['id'];
$order = getOrderById($conn, $order_id);

// Check if order exists and belongs to the user
if(!$order || ($order['user_id'] != $_SESSION['user_id'] && !isAdmin())) {
  redirect('orders.php', 'Order not found', 'danger');
}

// Get order items
$order_items = getOrderItems($conn, $order_id);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Order Details - Nova Wear</title>
  <link rel="stylesheet" href="assets/css/style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    .account-container {
      display: grid;
      grid-template-columns: 250px 1fr;
      gap: 30px;
      margin: 40px 0;
    }
    
    .account-sidebar {
      background-color: #fff;
      padding: 20px;
      border-radius: 8px;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
      height: fit-content;
    }
    
    .account-sidebar h3 {
      margin-bottom: 20px;
      padding-bottom: 10px;
      border-bottom: 1px solid #eee;
    }
    
    .account-menu {
      list-style: none;
      padding: 0;
    }
    
    .account-menu li {
      margin-bottom: 10px;
    }
    
    .account-menu li a {
      display: flex;
      align-items: center;
      padding: 10px;
      border-radius: 4px;
      transition: background-color 0.3s;
    }
    
    .account-menu li a:hover,
    .account-menu li a.active {
      background-color: #f5f5f5;
      color: #4a00e0;
    }
    
    .account-menu li a i {
      margin-right: 10px;
      width: 20px;
      text-align: center;
    }
    
    .account-content {
      background-color: #fff;
      padding: 30px;
      border-radius: 8px;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    }
    
    .account-content h2 {
      margin-bottom: 30px;
      padding-bottom: 15px;
      border-bottom: 1px solid #eee;
    }
    
    .order-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 30px;
    }
    
    .order-header h2 {
      margin-bottom: 0;
      padding-bottom: 0;
      border-bottom: none;
    }
    
    .order-meta {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 30px;
      margin-bottom: 30px;
    }
    
    .order-section {
      margin-bottom: 30px;
    }
    
    .order-section h3 {
      margin-bottom: 15px;
      padding-bottom: 10px;
      border-bottom: 1px solid #eee;
      font-size: 18px;
    }
    
    .order-details {
      margin-bottom: 20px;
    }
    
    .detail-row {
      display: flex;
      margin-bottom: 10px;
    }
    
    .detail-label {
      font-weight: 700;
      width: 150px;
    }
    
    .status-badge {
      display: inline-block;
      padding: 5px 10px;
      border-radius: 20px;
      font-size: 12px;
      font-weight: 700;
      text-transform: uppercase;
    }
    
    .status-pending {
      background-color: #f39c12;
      color: #fff;
    }
    
    .status-processing {
      background-color: #3498db;
      color: #fff;
    }
    
    .status-shipped {
      background-color: #2ecc71;
      color: #fff;
    }
    
    .status-delivered {
      background-color: #27ae60;
      color: #fff;
    }
    
    .status-cancelled {
      background-color: #e74c3c;
      color: #fff;
    }
    
    .order-items {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 30px;
    }
    
    .order-items th,
    .order-items td {
      padding: 12px 15px;
      text-align: left;
      border-bottom: 1px solid #eee;
    }
    
    .order-items th {
      background-color: #f9f9f9;
      font-weight: 600;
    }
    
    .product-info {
      display: flex;
      align-items: center;
    }
    
    .product-image {
      width: 60px;
      height: 60px;
      border-radius: 4px;
      overflow: hidden;
      margin-right: 15px;
    }
    
    .product-image img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }
    
    .order-summary {
      margin-top: 30px;
      text-align: right;
    }
    
    .summary-row {
      display: flex;
      justify-content: flex-end;
      margin-bottom: 10px;
    }
    
    .summary-label {
      font-weight: 700;
      width: 150px;
      text-align: left;
      margin-right: 20px;
    }
    
    .summary-value {
      width: 100px;
      text-align: right;
    }
    
    .summary-row.total {
      font-size: 18px;
      font-weight: 700;
      margin-top: 10px;
      padding-top: 10px;
      border-top: 1px solid #eee;
    }
    
    .shipping-address {
      white-space: pre-line;
      line-height: 1.6;
    }
    
    @media (max-width: 768px) {
      .account-container {
        grid-template-columns: 1fr;
      }
      
      .order-meta {
        grid-template-columns: 1fr;
        gap: 20px;
      }
      
      .order-items thead {
        display: none;
      }
      
      .order-items tbody, 
      .order-items tr, 
      .order-items td {
        display: block;
        width: 100%;
      }
      
      .order-items tr {
        margin-bottom: 20px;
        border: 1px solid #eee;
        border-radius: 8px;
        overflow: hidden;
      }
      
      .order-items td {
        text-align: right;
        padding: 10px;
        position: relative;
        border-bottom: 1px solid #eee;
      }
      
      .order-items td:last-child {
        border-bottom: none;
      }
      
      .order-items td::before {
        content: attr(data-label);
        position: absolute;
        left: 10px;
        top: 10px;
        font-weight: 700;
      }
      
      .product-info {
        justify-content: flex-end;
      }
    }
  </style>
</head>
<body>
  <?php include 'includes/header.php'; ?>
  
  <main class="container">
    <div class="account-container">
      <div class="account-sidebar">
        <h3>My Account</h3>
        
        <ul class="account-menu">
          <li><a href="account.php"><i class="fas fa-user"></i> Account Details</a></li>
          <li><a href="orders.php" class="active"><i class="fas fa-shopping-bag"></i> My Orders</a></li>
          <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
        </ul>
      </div>
      
      <div class="account-content">
        <div class="order-header">
          <h2>Order #<?php echo $order['id']; ?></h2>
          <a href="orders.php" class="btn btn-outline btn-sm">Back to Orders</a>
        </div>
        
        <div class="order-meta">
          <div class="order-section">
            <h3>Order Details</h3>
            
            <div class="order-details">
              <div class="detail-row">
                <div class="detail-label">Order Number:</div>
                <div class="detail-value">#<?php echo $order['id']; ?></div>
              </div>
              
              <div class="detail-row">
                <div class="detail-label">Order Date:</div>
                <div class="detail-value"><?php echo date('F j, Y', strtotime($order['created_at'])); ?></div>
              </div>
              
              <div class="detail-row">
                <div class="detail-label">Order Status:</div>
                <div class="detail-value">
                  <span class="status-badge status-<?php echo $order['status']; ?>">
                    <?php echo ucfirst($order['status']); ?>
                  </span>
                </div>
              </div>
              
              <div class="detail-row">
                <div class="detail-label">Payment Status:</div>
                <div class="detail-value">
                  <span class="status-badge status-<?php echo $order['payment_status']; ?>">
                    <?php echo ucfirst($order['payment_status']); ?>
                  </span>
                </div>
              </div>
            </div>
          </div>
          
          <div class="order-section">
            <h3>Shipping Information</h3>
            
            <div class="shipping-address">
              <?php echo nl2br(htmlspecialchars($order['shipping_address'])); ?>
            </div>
          </div>
        </div>
        
        <div class="order-section">
          <h3>Order Items</h3>
          
          <table class="order-items">
            <thead>
              <tr>
                <th>Product</th>
                <th>Price</th>
                <th>Quantity</th>
                <th>Total</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach($order_items as $item): ?>
                <tr>
                  <td data-label="Product">
                    <div class="product-info">
                      <div class="product-image">
                        <img src="assets/images/products/<?php echo htmlspecialchars($item['image']); ?>" alt="<?php echo htmlspecialchars($item['name']); ?>">
                      </div>
                      <div>
                        <h4><?php echo htmlspecialchars($item['name']); ?></h4>
                      </div>
                    </div>
                  </td>
                  <td data-label="Price">₱<?php echo number_format($item['price'], 2); ?></td>
                  <td data-label="Quantity"><?php echo $item['quantity']; ?></td>
                  <td data-label="Total">₱<?php echo number_format($item['price'] * $item['quantity'], 2); ?></td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
          
          <div class="order-summary">
            <div class="summary-row">
              <div class="summary-label">Subtotal:</div>
              <div class="summary-value">₱<?php echo number_format($order['total_amount'], 2); ?></div>
            </div>
            
            <div class="summary-row">
              <div class="summary-label">Shipping:</div>
              <div class="summary-value">Free</div>
            </div>
            
            <div class="summary-row total">
              <div class="summary-label">Total:</div>
              <div class="summary-value">₱<?php echo number_format($order['total_amount'], 2); ?></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </main>
  
  <?php include 'includes/footer.php'; ?>
  <script src="assets/js/main.js"></script>
</body>
</html>

