<?php
session_start();
include 'config/database.php';
include 'includes/functions.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>About Us - Tinamad Finds</title>
  <link rel="stylesheet" href="assets/css/style.css">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>

    .page-title {
      text-align: center;
      font-size: 2.5rem;
      margin-bottom: 40px;
      color:rgb(81, 20, 203);
      position: relative;
    }

    .about-section {
      background: white;
      border-radius: 10px;
      padding: 30px;
      margin-bottom: 30px;
      box-shadow: 0 5px 15px rgba(0,0,0,0.05);
      border-left: 4px solid #4a00e0;
    }

    .about-section h2 {
      color: #333;
      margin-bottom: 20px;
      font-size: 1.8rem;
    }

    .about-section p {
      line-height: 1.8;
      margin-bottom: 15px;
      color: #555;
    }

    .about-values {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 20px;
      margin-top: 30px;
    }

    .value-card {
      background: #f9f9ff;
      padding: 20px;
      border-radius: 8px;
      text-align: center;
      transition: transform 0.3s ease;
    }

    .value-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 10px 20px rgba(0,0,0,0.1);
    }

    .value-icon {
      font-size: 2.5rem;
      color: #4a00e0;
      margin-bottom: 15px;
    }

    .value-card h3 {
      color: #4a00e0;
      margin-bottom: 10px;
    }

    .account-icon {
      position: fixed;
      top: 20px;
      right: 20px;
      z-index: 999;
    }

    .account-icon a {
      display: flex;
      align-items: center;
      justify-content: center;
      width: 40px;
      height: 40px;
      background: #f1f1f1;
      border-radius: 50%;
      color: #4a00e0;
      text-decoration: none;
      box-shadow: 0 4px 8px rgba(0,0,0,0.1);
      transition: background 0.3s;
    }

    .account-icon a:hover {
      background: #4a00e0;
      color: white;
    }

    @media (max-width: 768px) {
      .page-title {
        font-size: 2rem;
      }

      .about-section {
        padding: 20px;
      }

      .account-icon {
        top: 10px;
        right: 10px;
      }
    }
  </style>
</head>
<body>
  <?php include 'includes/header.php'; ?>

  <main class="container">
      <h1 class="page-title">About Tinamad Finds</h1>

      <div class="about-section">
          <h2>Our Thrift Story</h2>
          <p>Born from a love for unique finds and sustainable fashion, Tinamad Finds began as a small buy n sell business in Davao City bustling thrift markets in 2022. What started as a weekend hobby for founder Jeffrey Cuering quickly grew into a thriving online community of thrift enthusiasts.</p>
          <p>We specialize in curating high-quality secondhand garments that tell a story. Each piece in our collection is carefully handpicked, cleaned, and restored to give it new life while preserving its unique character.</p>
      </div>

      <div class="about-section">
          <h2>Why Thrift With Us?</h2>
          <p>At Tinamad Finds, we believe in the magic of pre-loved clothing. Our mission is to make sustainable fashion accessible while offering treasures you won't find in mainstream stores.</p>
          <p>We stand for:</p>
          <ul style="margin-left: 20px; list-style-type: disc; line-height: 1.8;">
              <li><strong>Quality:</strong> Every item is inspected for quality and condition</li>
              <li><strong>Sustainability:</strong> Giving clothes a second life reduces fashion waste</li>
              <li><strong>Affordability:</strong> Premium styles at a fraction of retail prices</li>
              <li><strong>Uniqueness:</strong> One-of-a-kind pieces with history and character</li>
          </ul>
      </div>

      <div class="about-section">
          <h2>Our Thrift Philosophy</h2>
          <div class="about-values">
              <div class="value-card">
                  <div class="value-icon">♻️</div>
                  <h3>Sustainable Style</h3>
                  <p>We're proud to be part of the circular fashion movement, keeping thousands of garments out of landfills each year.</p>
              </div>

              <div class="value-card">
                  <div class="value-icon">🔍</div>
                  <h3>Curated Selection</h3>
                  <p>Our team hunts for the best vintage and contemporary pieces so you don't have to dig through racks.</p>
              </div>

              <div class="value-card">
                  <div class="value-icon">❤️</div>
                  <h3>Community First</h3>
                  <p>We've built a family of thrift lovers who share styling tips and celebrate each other's finds.</p>
              </div>

              <div class="value-card">
                  <div class="value-icon">✨</div>
                  <h3>Treasure Hunting</h3>
                  <p>Every visit to Tinamad Finds is a new adventure - you never know what gems you'll discover!</p>
              </div>
          </div>
      </div>
  </main>

  <?php include 'includes/footer.php'; ?>
  <script src="assets/js/main.js"></script>
</body>
</html>
