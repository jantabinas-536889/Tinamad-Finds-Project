<?php
session_start();
include 'config/database.php';
include 'includes/functions.php';

$success_message = '';
$error_message = '';

// Process contact form submission
if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $subject = trim($_POST['subject']);
    $message = trim($_POST['message']);
    
    // Simple validation
    if(empty($name) || empty($email) || empty($subject) || empty($message)) {
        $error_message = 'Please fill in all fields';
    } elseif(!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error_message = 'Please enter a valid email address';
    } else {
        // In a real application, you would send an email here
        // For now, we'll just show a success message
        $success_message = 'Thank you for your message! We will get back to you soon.';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Contact Us - Tinamad Finds</title>
  <link rel="stylesheet" href="assets/css/style.css">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    :root {
      --primary-color:rgb(87, 24, 223);
      --secondary-color:rgb(82, 36, 220);
      --accent-color: #B9E0FF;
      --text-color: #333; 
      --light-gray: #f5f5f5;
      --white: #ffffff;
    }
    
    
    .page-title {
      text-align: center;
      font-size: 2.5rem;
      margin-bottom: 2rem;
      color: var(--primary-color);
      position: relative;
    }
    
    .page-title:after {
      content: '';
      display: block;
      width: 80px;
      height: 4px;
      background: var(--secondary-color);
      margin: 1rem auto;
      border-radius: 2px;
    }
    
    .page-content {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 2rem;
      margin-top: 2rem;
    }
    
    .alert {
      padding: 1rem;
      border-radius: 5px;
      margin-bottom: 1.5rem;
      font-weight: 500;
    }
    
    .alert-success {
      background-color: #d4edda;
      color: #155724;
      border: 1px solid #c3e6cb;
    }
    
    .alert-danger {
      background-color: #f8d7da;
      color: #721c24;
      border: 1px solid #f5c6cb;
    }
    
    .contact-section, .contact-info {
      background: var(--white);
      border-radius: 10px;
      padding: 2rem;
      box-shadow: 0 5px 15px rgba(0,0,0,0.05);
    }
    
    .contact-section h2, .contact-info h2 {
      color: var(--primary-color);
      margin-bottom: 1.5rem;
      font-size: 1.5rem;
    }
    
    .contact-section p {
      color: var(--text-color);
      margin-bottom: 1.5rem;
      line-height: 1.6;
    }
    
    .form-group {
      margin-bottom: 1.5rem;
    }
    
    .form-group label {
      display: block;
      margin-bottom: 0.5rem;
      font-weight: 500;
      color: var(--text-color);
    }
    
    .form-group input,
    .form-group textarea {
      width: 100%;
      padding: 0.8rem;
      border: 1px solid #ddd;
      border-radius: 5px;
      font-family: 'Poppins', sans-serif;
      transition: border-color 0.3s;
    }
    
    .form-group input:focus,
    .form-group textarea:focus {
      outline: none;
      border-color: var(--secondary-color);
    }
    
    .form-group textarea {
      min-height: 150px;
      resize: vertical;
    }
    
    .btn {
      background: var(--primary-color);
      color: white;
      border: none;
      padding: 0.8rem 1.5rem;
      border-radius: 5px;
      cursor: pointer;
      font-weight: 500;
      transition: background 0.3s;
    }
    
    .btn:hover {
      background: var(--secondary-color);
    }
    
    .contact-info-item {
      display: flex;
      align-items: flex-start;
      margin-bottom: 1.5rem;
    }
    
    .contact-info-item i {
      font-size: 1.2rem;
      color: var(--primary-color);
      margin-right: 1rem;
      margin-top: 0.3rem;
    }
    
    .contact-info-item h3 {
      font-size: 1rem;
      margin-bottom: 0.3rem;
      color: var(--primary-color);
    }
    
    .contact-info-item p {
      color: var(--text-color);
      margin: 0;
      line-height: 1.5;
    }
    
    .social-links {
      display: flex;
      gap: 1rem;
      margin-top: 2rem;
    }
    
    .social-links a {
      display: flex;
      align-items: center;
      justify-content: center;
      width: 40px;
      height: 40px;
      background: var(--light-gray);
      color: var(--primary-color);
      border-radius: 50%;
      transition: all 0.3s;
    }
    
    .social-links a:hover {
      background: var(--primary-color);
      color: white;
      transform: translateY(-3px);
    }
    
    @media (max-width: 768px) {
      .page-content {
        grid-template-columns: 1fr;
      }
      
      .page-title {
        font-size: 2rem;
      }
      
      .contact-section, .contact-info {
        padding: 1.5rem;
      }
    }
  </style>
</head>
<body>
  <?php include 'includes/header.php'; ?>
  
  <main class="container">
      <h1 class="page-title">Contact Us</h1>
      
      <div class="page-content">
          <?php if($success_message): ?>
              <div class="alert alert-success">
                  <?php echo $success_message; ?>
              </div>
          <?php endif; ?>
          
          <?php if($error_message): ?>
              <div class="alert alert-danger">
                  <?php echo $error_message; ?>
              </div>
          <?php endif; ?>
          
          <div class="contact-section">
              <h2>Get in Touch</h2>
              <p>Have questions about our thrifted finds? Need help with an order? Want to share your latest vintage treasure? We're all ears! Reach out and our team will get back to you within 24 hours.</p>
              
              <form class="contact-form" action="contact.php" method="post">
                  <div class="form-group">
                      <label for="name">Your Name</label>
                      <input type="text" id="name" name="name" value="<?php echo isset($_POST['name']) ? htmlspecialchars($_POST['name']) : ''; ?>" required>
                  </div>
                  
                  <div class="form-group">
                      <label for="email">Your Email</label>
                      <input type="email" id="email" name="email" value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>" required>
                  </div>
                  
                  <div class="form-group">
                      <label for="subject">Subject</label>
                      <input type="text" id="subject" name="subject" value="<?php echo isset($_POST['subject']) ? htmlspecialchars($_POST['subject']) : ''; ?>" required>
                  </div>
                  
                  <div class="form-group">
                      <label for="message">Your Message</label>
                      <textarea id="message" name="message" required><?php echo isset($_POST['message']) ? htmlspecialchars($_POST['message']) : ''; ?></textarea>
                  </div>
                  
                  <button type="submit" class="btn">Send Message</button>
              </form>
          </div>
          
          <div class="contact-info">
              <h2>Our Details</h2>
              
              <div class="contact-info-item">
                  <i class="fas fa-map-marker-alt"></i>
                  <div>
                      <h3>Thrift Shop Location</h3>
                      <p>Maa, Davao City<br>Zip Code: 8000</p>
                  </div>
              </div>
              
              <div class="contact-info-item">
                  <i class="fas fa-phone"></i>
                  <div>
                      <h3>Call Us</h3>
                      <p>+63 912 345 6789</p>
                  </div>
              </div>
              
              <div class="contact-info-item">
                  <i class="fas fa-envelope"></i>
                  <div>
                      <h3>Email Us</h3>
                      <p>hello@tinamadfinds.com</p>
                  </div>
              </div>
              
              <div class="contact-info-item">
                  <i class="fas fa-clock"></i>
                  <div>
                      <h3>Thrifting Hours</h3>
                      <p>Monday - Saturday: 10AM - 7PM<br>Sunday: 12PM - 5PM</p>
                  </div>
              </div>
              
              <div class="social-links">
                  <a href="#" aria-label="Facebook"><i class="fab fa-facebook-f"></i></a>
                  <a href="#" aria-label="Instagram"><i class="fab fa-instagram"></i></a>
                  <a href="#" aria-label="Twitter"><i class="fab fa-twitter"></i></a>
                  <a href="#" aria-label="TikTok"><i class="fab fa-tiktok"></i></a>
              </div>
          </div>
      </div>
  </main>
  
  <?php include 'includes/footer.php'; ?>
  <script src="assets/js/main.js"></script>
</body>
</html>