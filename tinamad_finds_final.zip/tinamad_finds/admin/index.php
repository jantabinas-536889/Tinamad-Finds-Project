<?php
session_start();
include '../config/database.php';
include '../includes/functions.php';

// Check if user is logged in and is admin
if(!isLoggedIn() || !isAdmin()) {
    redirect('../login.php', 'You do not have permission to access this page', 'danger');
}

// Get dashboard stats
$sql = "SELECT COUNT(*) as total FROM products";
$stmt = $conn->prepare($sql);
$stmt->execute();
$product_count = $stmt->fetch()['total'];

$sql = "SELECT COUNT(*) as total FROM users WHERE role = 'customer'";
$stmt = $conn->prepare($sql);
$stmt->execute();
$customer_count = $stmt->fetch()['total'];

$sql = "SELECT COUNT(*) as total FROM orders";
$stmt = $conn->prepare($sql);
$stmt->execute();
$order_count = $stmt->fetch()['total'];

$sql = "SELECT SUM(total_amount) as total FROM orders WHERE payment_status = 'paid'";
$stmt = $conn->prepare($sql);
$stmt->execute();
$revenue = $stmt->fetch()['total'] ?? 0;

// Get recent orders
$recent_orders = getAllOrders($conn, 5);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Tinamad Finds</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .admin-container {
            display: grid;
            grid-template-columns: 250px 1fr;
            min-height: 100vh;
        }
        
        .admin-sidebar {
            background-color: #2c3e50;
            color: #fff;
            padding: 20px 0;
        }
        
        .admin-logo {
            padding: 0 20px 20px;
            margin-bottom: 20px;
            border-bottom: 1px solid #3d5166;
            display: flex;
            align-items: center;
        }
        
        .admin-logo h1 {
            font-size: 20px;
            margin-left: 10px;
        }
        
        .admin-menu ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        
        .admin-menu ul li {
            margin-bottom: 5px;
        }
        
        .admin-menu ul li a {
            display: flex;
            align-items: center;
            padding: 12px 20px;
            color: #ecf0f1;
            text-decoration: none;
            transition: background-color 0.3s;
        }
        
        .admin-menu ul li a:hover,
        .admin-menu ul li a.active {
            background-color: #3d5166;
        }
        
        .admin-menu ul li a i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        
        .admin-content {
            padding: 20px;
            background-color: #f5f5f5;
        }
        
        .admin-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }
        
        .admin-header h2 {
            font-size: 24px;
        }
        
        .admin-user {
            display: flex;
            align-items: center;
        }
        
        .admin-user span {
            margin-right: 10px;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        
        .stat-card h3 {
            font-size: 16px;
            color: #7f8c8d;
            margin-bottom: 10px;
        }
        
        .stat-card .stat-value {
            font-size: 28px;
            font-weight: 700;
            margin-bottom: 5px;
        }
        
        .stat-card .stat-icon {
            float: right;
            font-size: 40px;
            color: #ecf0f1;
        }
        
        .stat-card.products {
            background-color: #3498db;
            color: #fff;
        }
        
        .stat-card.customers {
            background-color: #2ecc71;
            color: #fff;
        }
        
        .stat-card.orders {
            background-color: #e74c3c;
            color: #fff;
        }
        
        .stat-card.revenue {
            background-color: #f39c12;
            color: #fff;
        }
        
        .recent-orders {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        
        .recent-orders h3 {
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 1px solid #eee;
        }
        
        .orders-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .orders-table th,
        .orders-table td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }
        
        .orders-table th {
            background-color: #f9f9f9;
        }
        
        .status-badge {
            display: inline-block;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 700;
            text-transform: uppercase;
        }
        
        .status-pending {
            background-color: #f39c12;
            color: #fff;
        }
        
        .status-processing {
            background-color: #3498db;
            color: #fff;
        }
        
        .status-shipped {
            background-color: #2ecc71;
            color: #fff;
        }
        
        .status-delivered {
            background-color: #27ae60;
            color: #fff;
        }
        
        .status-cancelled {
            background-color: #e74c3c;
            color: #fff;
        }
        
        .view-all {
            display: block;
            text-align: center;
            margin-top: 20px;
        }
        
        @media (max-width: 992px) {
            .admin-container {
                grid-template-columns: 1fr;
            }
            
            .admin-sidebar {
                display: none;
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <div class="admin-sidebar">
            <div class="admin-logo">
                <i class="fas fa-tshirt"></i>
                <h1>TinamadFinds Admin</h1>
            </div>
            
            <div class="admin-menu">
                <ul>
                    <li><a href="index.php" class="active"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                    <li><a href="products.php"><i class="fas fa-box"></i> Products</a></li>
                    <li><a href="orders.php"><i class="fas fa-shopping-cart"></i> Orders</a></li>
                    <li><a href="customers.php"><i class="fas fa-users"></i> Customers</a></li>
                    <li><a href="../index.php" target="_blank"><i class="fas fa-external-link-alt"></i> View Store</a></li>
                    <li><a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                </ul>
            </div>
        </div>
        
        <div class="admin-content">
            <div class="admin-header">
                <h2>Dashboard</h2>
                
                <div class="admin-user">
                    <span>Welcome, <?php echo $_SESSION['username']; ?></span>
                    <a href="../logout.php" class="btn btn-outline btn-sm">Logout</a>
                </div>
            </div>
            
            <div class="stats-grid">
                <div class="stat-card products">
                    <i class="fas fa-box stat-icon"></i>
                    <h3>Total Products</h3>
                    <div class="stat-value"><?php echo $product_count; ?></div>
                </div>
                
                <div class="stat-card customers">
                    <i class="fas fa-users stat-icon"></i>
                    <h3>Total Customers</h3>
                    <div class="stat-value"><?php echo $customer_count; ?></div>
                </div>
                
                <div class="stat-card orders">
                    <i class="fas fa-shopping-cart stat-icon"></i>
                    <h3>Total Orders</h3>
                    <div class="stat-value"><?php echo $order_count; ?></div>
                </div>
                
                <div class="stat-card revenue">
                <i class="fas fa-peso-sign stat-icon"></i>
                <h3>Total Revenue</h3>
                <div class="stat-value">₱<?php echo number_format($revenue, 2); ?></div>
                </div>
            </div>
            
            <div class="recent-orders">
                <h3>Recent Orders</h3>
                
                <table class="orders-table">
                    <thead>
                        <tr>
                            <th>Order ID</th>
                            <th>Customer</th>
                            <th>Date</th>
                            <th>Total</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($recent_orders as $order): ?>
                            <tr>
                                <td>#<?php echo $order['id']; ?></td>
                                <td><?php echo htmlspecialchars($order['username']); ?></td>
                                <td><?php echo date('M d, Y', strtotime($order['created_at'])); ?></td>
                                <td>₱<?php echo number_format($order['total_amount'], 2); ?></td>
                                <td>
                                    <span class="status-badge status-<?php echo $order['status']; ?>">
                                        <?php echo ucfirst($order['status']); ?>
                                    </span>
                                </td>
                                <td>
                                    <a href="order_details.php?id=<?php echo $order['id']; ?>" class="btn btn-sm">View</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                
                <a href="orders.php" class="view-all">View All Orders</a>
            </div>
        </div>
    </div>
</body>
</html>

