<?php
session_start();
include '../config/database.php';
include '../includes/functions.php';

// Check if user is logged in and is admin
if(!isLoggedIn() || !isAdmin()) {
  redirect('../login.php', 'You do not have permission to access this page', 'danger');
}

// Pagination
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 10;
$offset = ($page - 1) * $limit;

// Get customers with pagination
$sql = "SELECT * FROM users WHERE role = 'customer' ORDER BY created_at DESC LIMIT :limit OFFSET :offset";
$stmt = $conn->prepare($sql);
$stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
$stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$customers = $stmt->fetchAll();

// Get total customers count for pagination
$sql = "SELECT COUNT(*) as total FROM users WHERE role = 'customer'";
$stmt = $conn->prepare($sql);
$stmt->execute();
$total_customers = $stmt->fetch()['total'];
$total_pages = ceil($total_customers / $limit);

// Handle customer deletion
if(isset($_GET['delete']) && is_numeric($_GET['delete'])) {
  $customer_id = $_GET['delete'];
  
  // Check if customer exists
  $sql = "SELECT * FROM users WHERE id = :id AND role = 'customer'";
  $stmt = $conn->prepare($sql);
  $stmt->bindParam(':id', $customer_id, PDO::PARAM_INT);
  $stmt->execute();
  $customer = $stmt->fetch();
  
  if($customer) {
    // Delete customer
    $sql = "DELETE FROM users WHERE id = :id";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':id', $customer_id, PDO::PARAM_INT);
    
    if($stmt->execute()) {
      redirect('customers.php', 'Customer deleted successfully', 'success');
    } else {
      redirect('customers.php', 'Failed to delete customer', 'danger');
    }
  } else {
    redirect('customers.php', 'Customer not found', 'danger');
  }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Manage Customers - Tinamad Finds Admin</title>
  <link rel="stylesheet" href="../assets/css/style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    .admin-container {
      display: grid;
      grid-template-columns: 250px 1fr;
      min-height: 100vh;
    }
    
    .admin-sidebar {
      background-color: #2c3e50;
      color: #fff;
      padding: 20px 0;
    }
    
    .admin-logo {
      padding: 0 20px 20px;
      margin-bottom: 20px;
      border-bottom: 1px solid #3d5166;
      display: flex;
      align-items: center;
    }
    
    .admin-logo h1 {
      font-size: 20px;
      margin-left: 10px;
    }
    
    .admin-menu ul {
      list-style: none;
      padding: 0;
      margin: 0;
    }
    
    .admin-menu ul li {
      margin-bottom: 5px;
    }
    
    .admin-menu ul li a {
      display: flex;
      align-items: center;
      padding: 12px 20px;
      color: #ecf0f1;
      text-decoration: none;
      transition: background-color 0.3s;
    }
    
    .admin-menu ul li a:hover,
    .admin-menu ul li a.active {
      background-color: #3d5166;
    }
    
    .admin-menu ul li a i {
      margin-right: 10px;
      width: 20px;
      text-align: center;
    }
    
    .admin-content {
      padding: 20px;
      background-color: #f5f5f5;
    }
    
    .admin-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 30px;
    }
    
    .admin-header h2 {
      font-size: 24px;
    }
    
    .customers-container {
      background-color: #fff;
      padding: 20px;
      border-radius: 8px;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    }
    
    .customers-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 20px;
      padding-bottom: 10px;
      border-bottom: 1px solid #eee;
    }
    
    .customers-table {
      width: 100%;
      border-collapse: collapse;
    }
    
    .customers-table th,
    .customers-table td {
      padding: 12px 15px;
      text-align: left;
      border-bottom: 1px solid #eee;
    }
    
    .customers-table th {
      background-color: #f9f9f9;
    }
    
    .customer-actions {
      display: flex;
      gap: 5px;
    }
    
    .customer-actions a,
    .customer-actions button {
      padding: 5px 10px;
      font-size: 12px;
    }
    
    .pagination {
      display: flex;
      justify-content: center;
      margin-top: 30px;
    }
    
    .pagination a,
    .pagination span {
      display: inline-block;
      padding: 8px 12px;
      margin: 0 5px;
      border-radius: 4px;
      background-color: #fff;
      border: 1px solid #ddd;
      color: #333;
      text-decoration: none;
    }
    
    .pagination a:hover {
      background-color: #f5f5f5;
    }
    
    .pagination .active {
      background-color: #4a00e0;
      color: #fff;
      border-color: #4a00e0;
    }
    
    .pagination .disabled {
      color: #aaa;
      cursor: not-allowed;
    }
    
    .modal {
      display: none;
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background-color: rgba(0, 0, 0, 0.5);
      z-index: 1000;
      justify-content: center;
      align-items: center;
    }
    
    .modal.active {
      display: flex;
    }
    
    .modal-content {
      background-color: #fff;
      padding: 30px;
      border-radius: 8px;
      width: 500px;
      max-width: 90%;
    }
    
    .modal-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 20px;
    }
    
    .modal-header h3 {
      margin: 0;
    }
    
    .modal-close {
      background: none;
      border: none;
      font-size: 20px;
      cursor: pointer;
    }
    
    .customer-details {
      margin-bottom: 20px;
    }
    
    .detail-row {
      display: flex;
      margin-bottom: 10px;
    }
    
    .detail-label {
      font-weight: 700;
      width: 150px;
    }
    
    @media (max-width: 992px) {
      .admin-container {
        grid-template-columns: 1fr;
      }
      
      .admin-sidebar {
        display: none;
      }
    }
  </style>
</head>
<body>
  <div class="admin-container">
    <div class="admin-sidebar">
      <div class="admin-logo">
        <i class="fas fa-tshirt"></i>
        <h1>TinamadFinds Admin</h1>
      </div>
      
      <div class="admin-menu">
        <ul>
          <li><a href="index.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
          <li><a href="products.php"><i class="fas fa-box"></i> Products</a></li>
          <li><a href="orders.php"><i class="fas fa-shopping-cart"></i> Orders</a></li>
          <li><a href="customers.php" class="active"><i class="fas fa-users"></i> Customers</a></li>
          <li><a href="../index.php" target="_blank"><i class="fas fa-external-link-alt"></i> View Store</a></li>
          <li><a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
        </ul>
      </div>
    </div>
    
    <div class="admin-content">
      <div class="admin-header">
        <h2>Manage Customers</h2>
      </div>
      
      <div class="customers-container">
        <div class="customers-header">
          <h3>All Customers</h3>
          
          <div class="search-box">
            <input type="text" id="customerSearch" placeholder="Search customers...">
          </div>
        </div>
        
        <?php echo displayMessage(); ?>
        
        <table class="customers-table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Username</th>
              <th>Email</th>
              <th>Name</th>
              <th>Registered Date</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach($customers as $customer): ?>
              <tr>
                <td><?php echo $customer['id']; ?></td>
                <td><?php echo htmlspecialchars($customer['username']); ?></td>
                <td><?php echo htmlspecialchars($customer['email']); ?></td>
                <td>
                  <?php 
                  $name = trim($customer['first_name'] . ' ' . $customer['last_name']);
                  echo !empty($name) ? htmlspecialchars($name) : 'N/A'; 
                  ?>
                </td>
                <td><?php echo date('M d, Y', strtotime($customer['created_at'])); ?></td>
                <td>
                  <div class="customer-actions">
                    <button class="btn btn-sm view-customer-btn" data-customer-id="<?php echo $customer['id']; ?>">View</button>
                    <a href="customers.php?delete=<?php echo $customer['id']; ?>" class="btn btn-sm btn-outline" onclick="return confirm('Are you sure you want to delete this customer?')">Delete</a>
                  </div>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
        
        <?php if($total_pages > 1): ?>
          <div class="pagination">
            <?php if($page > 1): ?>
              <a href="?page=<?php echo $page - 1; ?>">&laquo; Previous</a>
            <?php else: ?>
              <span class="disabled">&laquo; Previous</span>
            <?php endif; ?>
            
            <?php for($i = 1; $i <= $total_pages; $i++): ?>
              <?php if($i == $page): ?>
                <span class="active"><?php echo $i; ?></span>
              <?php else: ?>
                <a href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
              <?php endif; ?>
            <?php endfor; ?>
            
            <?php if($page < $total_pages): ?>
              <a href="?page=<?php echo $page + 1; ?>">Next &raquo;</a>
            <?php else: ?>
              <span class="disabled">Next &raquo;</span>
            <?php endif; ?>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
  
  <!-- Customer Details Modal -->
  <div id="customerModal" class="modal">
    <div class="modal-content">
      <div class="modal-header">
        <h3>Customer Details</h3>
        <button class="modal-close">&times;</button>
      </div>
      
      <div class="modal-body">
        <div class="customer-details">
          <div class="detail-row">
            <div class="detail-label">Username:</div>
            <div class="detail-value" id="modal-username"></div>
          </div>
          
          <div class="detail-row">
            <div class="detail-label">Email:</div>
            <div class="detail-value" id="modal-email"></div>
          </div>
          
          <div class="detail-row">
            <div class="detail-label">Name:</div>
            <div class="detail-value" id="modal-name"></div>
          </div>
          
          <div class="detail-row">
            <div class="detail-label">Address:</div>
            <div class="detail-value" id="modal-address"></div>
          </div>
          
          <div class="detail-row">
            <div class="detail-label">City:</div>
            <div class="detail-value" id="modal-city"></div>
          </div>
          
          <div class="detail-row">
            <div class="detail-label">Postal Code:</div>
            <div class="detail-value" id="modal-postal-code"></div>
          </div>
          
          <div class="detail-row">
            <div class="detail-label">Country:</div>
            <div class="detail-value" id="modal-country"></div>
          </div>
          
          <div class="detail-row">
            <div class="detail-label">Phone:</div>
            <div class="detail-value" id="modal-phone"></div>
          </div>
          
          <div class="detail-row">
            <div class="detail-label">Registered:</div>
            <div class="detail-value" id="modal-created-at"></div>
          </div>
        </div>
      </div>
    </div>
  </div>
  
  <script>
    // Customer search functionality
    const searchInput = document.getElementById('customerSearch');
    const customerRows = document.querySelectorAll('.customers-table tbody tr');
    
    searchInput.addEventListener('keyup', function() {
      const searchTerm = this.value.toLowerCase();
      
      customerRows.forEach(row => {
        const username = row.querySelector('td:nth-child(2)').textContent.toLowerCase();
        const email = row.querySelector('td:nth-child(3)').textContent.toLowerCase();
        const name = row.querySelector('td:nth-child(4)').textContent.toLowerCase();
        
        if(username.includes(searchTerm) || email.includes(searchTerm) || name.includes(searchTerm)) {
          row.style.display = '';
        } else {
          row.style.display = 'none';
        }
      });
    });
    
    // Modal functionality
    const viewCustomerBtns = document.querySelectorAll('.view-customer-btn');
    const customerModal = document.getElementById('customerModal');
    const modalCloseBtns = document.querySelectorAll('.modal-close');
    
    viewCustomerBtns.forEach(btn => {
      btn.addEventListener('click', function() {
        const customerId = this.getAttribute('data-customer-id');
        
        // Fetch customer details via AJAX
        fetch(`get_customer.php?id=${customerId}`)
          .then(response => response.json())
          .then(customer => {
            document.getElementById('modal-username').textContent = customer.username;
            document.getElementById('modal-email').textContent = customer.email;
            document.getElementById('modal-name').textContent = customer.first_name + ' ' + customer.last_name;
            document.getElementById('modal-address').textContent = customer.address || 'N/A';
            document.getElementById('modal-city').textContent = customer.city || 'N/A';
            document.getElementById('modal-postal-code').textContent = customer.postal_code || 'N/A';
            document.getElementById('modal-country').textContent = customer.country || 'N/A';
            document.getElementById('modal-phone').textContent = customer.phone || 'N/A';
            document.getElementById('modal-created-at').textContent = new Date(customer.created_at).toLocaleDateString();
            
            customerModal.classList.add('active');
          })
          .catch(error => {
            console.error('Error fetching customer details:', error);
            alert('Failed to load customer details. Please try again.');
          });
      });
    });
    
    modalCloseBtns.forEach(btn => {
      btn.addEventListener('click', function() {
        customerModal.classList.remove('active');
      });
    });
    
    // Close modal when clicking outside
    window.addEventListener('click', function(event) {
      if (event.target === customerModal) {
        customerModal.classList.remove('active');
      }
    });
  </script>
</body>
</html>

