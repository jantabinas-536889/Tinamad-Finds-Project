<?php
session_start();
include '../config/database.php';
include '../includes/functions.php';

// Check if user is logged in and is admin
if(!isLoggedIn() || !isAdmin()) {
  redirect('../login.php', 'You do not have permission to access this page', 'danger');
}

// Pagination
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 10;
$offset = ($page - 1) * $limit;

// Get orders with pagination
$orders = getAllOrders($conn, $limit, $offset);

// Get total orders count for pagination
$sql = "SELECT COUNT(*) as total FROM orders";
$stmt = $conn->prepare($sql);
$stmt->execute();
$total_orders = $stmt->fetch()['total'];
$total_pages = ceil($total_orders / $limit);

// Handle order status update
if(isset($_POST['update_status'])) {
  $order_id = $_POST['order_id'];
  $status = $_POST['status'];
  
  if(updateOrderStatus($conn, $order_id, $status)) {
    redirect('orders.php', 'Order status updated successfully', 'success');
  } else {
    redirect('orders.php', 'Failed to update order status', 'danger');
  }
}

// Handle payment status update
if(isset($_POST['update_payment'])) {
  $order_id = $_POST['order_id'];
  $payment_status = $_POST['payment_status'];
  
  if(updatePaymentStatus($conn, $order_id, $payment_status)) {
    redirect('orders.php', 'Payment status updated successfully', 'success');
  } else {
    redirect('orders.php', 'Failed to update payment status', 'danger');
  }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Manage Orders - Tinamad Finds Admin</title>
  <link rel="stylesheet" href="../assets/css/style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    .admin-container {
      display: grid;
      grid-template-columns: 250px 1fr;
      min-height: 100vh;
    }
    
    .admin-sidebar {
      background-color: #2c3e50;
      color: #fff;
      padding: 20px 0;
    }
    
    .admin-logo {
      padding: 0 20px 20px;
      margin-bottom: 20px;
      border-bottom: 1px solid #3d5166;
      display: flex;
      align-items: center;
    }
    
    .admin-logo h1 {
      font-size: 20px;
      margin-left: 10px;
    }
    
    .admin-menu ul {
      list-style: none;
      padding: 0;
      margin: 0;
    }
    
    .admin-menu ul li {
      margin-bottom: 5px;
    }
    
    .admin-menu ul li a {
      display: flex;
      align-items: center;
      padding: 12px 20px;
      color: #ecf0f1;
      text-decoration: none;
      transition: background-color 0.3s;
    }
    
    .admin-menu ul li a:hover,
    .admin-menu ul li a.active {
      background-color: #3d5166;
    }
    
    .admin-menu ul li a i {
      margin-right: 10px;
      width: 20px;
      text-align: center;
    }
    
    .admin-content {
      padding: 20px;
      background-color: #f5f5f5;
    }
    
    .admin-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 30px;
    }
    
    .admin-header h2 {
      font-size: 24px;
    }
    
    .orders-container {
      background-color: #fff;
      padding: 20px;
      border-radius: 8px;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    }
    
    .orders-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 20px;
      padding-bottom: 10px;
      border-bottom: 1px solid #eee;
    }
    
    .orders-table {
      width: 100%;
      border-collapse: collapse;
    }
    
    .orders-table th,
    .orders-table td {
      padding: 12px 15px;
      text-align: left;
      border-bottom: 1px solid #eee;
    }
    
    .orders-table th {
      background-color: #f9f9f9;
    }
    
    .status-badge {
      display: inline-block;
      padding: 5px 10px;
      border-radius: 20px;
      font-size: 12px;
      font-weight: 700;
      text-transform: uppercase;
    }
    
    .status-pending {
      background-color: #f39c12;
      color: #fff;
    }
    
    .status-processing {
      background-color: #3498db;
      color: #fff;
    }
    
    .status-shipped {
      background-color: #2ecc71;
      color: #fff;
    }
    
    .status-delivered {
      background-color: #27ae60;
      color: #fff;
    }
    
    .status-cancelled {
      background-color: #e74c3c;
      color: #fff;
    }
    
    .status-paid {
      background-color: #2ecc71;
      color: #fff;
    }
    
    .status-failed {
      background-color: #e74c3c;
      color: #fff;
    }
    
    .order-actions {
      display: flex;
      gap: 5px;
    }
    
    .order-actions a,
    .order-actions button {
      padding: 5px 10px;
      font-size: 12px;
    }
    
    .pagination {
      display: flex;
      justify-content: center;
      margin-top: 30px;
    }
    
    .pagination a,
    .pagination span {
      display: inline-block;
      padding: 8px 12px;
      margin: 0 5px;
      border-radius: 4px;
      background-color: #fff;
      border: 1px solid #ddd;
      color: #333;
      text-decoration: none;
    }
    
    .pagination a:hover {
      background-color: #f5f5f5;
    }
    
    .pagination .active {
      background-color: #4a00e0;
      color: #fff;
      border-color: #4a00e0;
    }
    
    .pagination .disabled {
      color: #aaa;
      cursor: not-allowed;
    }
    
    .modal {
      display: none;
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background-color: rgba(0, 0, 0, 0.5);
      z-index: 1000;
      justify-content: center;
      align-items: center;
    }
    
    .modal.active {
      display: flex;
    }
    
    .modal-content {
      background-color: #fff;
      padding: 30px;
      border-radius: 8px;
      width: 400px;
      max-width: 90%;
    }
    
    .modal-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 20px;
    }
    
    .modal-header h3 {
      margin: 0;
    }
    
    .modal-close {
      background: none;
      border: none;
      font-size: 20px;
      cursor: pointer;
    }
    
    .modal-body {
      margin-bottom: 20px;
    }
    
    .modal-footer {
      display: flex;
      justify-content: flex-end;
      gap: 10px;
    }
    
    .form-group {
      margin-bottom: 20px;
    }
    
    .form-group label {
      display: block;
      margin-bottom: 5px;
      font-weight: 500;
    }
    
    .form-group select {
      width: 100%;
      padding: 10px;
      border: 1px solid #ddd;
      border-radius: 4px;
    }
    
    @media (max-width: 992px) {
      .admin-container {
        grid-template-columns: 1fr;
      }
      
      .admin-sidebar {
        display: none;
      }
    }
  </style>
</head>
<body>
  <div class="admin-container">
    <div class="admin-sidebar">
      <div class="admin-logo">
        <i class="fas fa-tshirt"></i>
        <h1>TinamadFinds Admin</h1>
      </div>
      
      <div class="admin-menu">
        <ul>
          <li><a href="index.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
          <li><a href="products.php"><i class="fas fa-box"></i> Products</a></li>
          <li><a href="orders.php" class="active"><i class="fas fa-shopping-cart"></i> Orders</a></li>
          <li><a href="customers.php"><i class="fas fa-users"></i> Customers</a></li>
          <li><a href="../index.php" target="_blank"><i class="fas fa-external-link-alt"></i> View Store</a></li>
          <li><a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
        </ul>
      </div>
    </div>
    
    <div class="admin-content">
      <div class="admin-header">
        <h2>Manage Orders</h2>
      </div>
      
      <div class="orders-container">
        <div class="orders-header">
          <h3>All Orders</h3>
          
          <div class="search-box">
            <input type="text" id="orderSearch" placeholder="Search orders...">
          </div>
        </div>
        
        <?php echo displayMessage(); ?>
        
        <table class="orders-table">
          <thead>
            <tr>
              <th>Order ID</th>
              <th>Customer</th>
              <th>Date</th>
              <th>Total</th>
              <th>Status</th>
              <th>Payment</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach($orders as $order): ?>
              <tr>
                <td>#<?php echo $order['id']; ?></td>
                <td><?php echo htmlspecialchars($order['username']); ?></td>
                <td><?php echo date('M d, Y', strtotime($order['created_at'])); ?></td>
                <td>₱<?php echo number_format($order['total_amount'], 2); ?></td>
                <td>
                  <span class="status-badge status-<?php echo $order['status']; ?>">
                    <?php echo ucfirst($order['status']); ?>
                  </span>
                </td>
                <td>
                  <span class="status-badge status-<?php echo $order['payment_status']; ?>">
                    <?php echo ucfirst($order['payment_status']); ?>
                  </span>
                </td>
                <td>
                  <div class="order-actions">
                    <a href="order_details.php?id=<?php echo $order['id']; ?>" class="btn btn-sm">View</a>
                    <button class="btn btn-sm btn-outline update-status-btn" data-order-id="<?php echo $order['id']; ?>">Update Status</button>
                    <button class="btn btn-sm btn-outline update-payment-btn" data-order-id="<?php echo $order['id']; ?>">Update Payment</button>
                  </div>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
        
        <?php if($total_pages > 1): ?>
          <div class="pagination">
            <?php if($page > 1): ?>
              <a href="?page=<?php echo $page - 1; ?>">&laquo; Previous</a>
            <?php else: ?>
              <span class="disabled">&laquo; Previous</span>
            <?php endif; ?>
            
            <?php for($i = 1; $i <= $total_pages; $i++): ?>
              <?php if($i == $page): ?>
                <span class="active"><?php echo $i; ?></span>
              <?php else: ?>
                <a href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
              <?php endif; ?>
            <?php endfor; ?>
            
            <?php if($page < $total_pages): ?>
              <a href="?page=<?php echo $page + 1; ?>">Next &raquo;</a>
            <?php else: ?>
              <span class="disabled">Next &raquo;</span>
            <?php endif; ?>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
  
  <!-- Update Order Status Modal -->
  <div id="updateStatusModal" class="modal">
    <div class="modal-content">
      <div class="modal-header">
        <h3>Update Order Status</h3>
        <button class="modal-close">&times;</button>
      </div>
      
      <form action="orders.php" method="post">
        <input type="hidden" name="order_id" id="statusOrderId">
        
        <div class="modal-body">
          <div class="form-group">
            <label for="status">Order Status</label>
            <select id="status" name="status" required>
              <option value="pending">Pending</option>
              <option value="processing">Processing</option>
              <option value="shipped">Shipped</option>
              <option value="delivered">Delivered</option>
              <option value="cancelled">Cancelled</option>
            </select>
          </div>
        </div>
        
        <div class="modal-footer">
          <button type="button" class="btn btn-outline modal-close-btn">Cancel</button>
          <button type="submit" name="update_status" class="btn">Update Status</button>
        </div>
      </form>
    </div>
  </div>
  
  <!-- Update Payment Status Modal -->
  <div id="updatePaymentModal" class="modal">
    <div class="modal-content">
      <div class="modal-header">
        <h3>Update Payment Status</h3>
        <button class="modal-close">&times;</button>
      </div>
      
      <form action="orders.php" method="post">
        <input type="hidden" name="order_id" id="paymentOrderId">
        
        <div class="modal-body">
          <div class="form-group">
            <label for="payment_status">Payment Status</label>
            <select id="payment_status" name="payment_status" required>
              <option value="pending">Pending</option>
              <option value="paid">Paid</option>
              <option value="failed">Failed</option>
            </select>
          </div>
        </div>
        
        <div class="modal-footer">
          <button type="button" class="btn btn-outline modal-close-btn">Cancel</button>
          <button type="submit" name="update_payment" class="btn">Update Payment</button>
        </div>
      </form>
    </div>
  </div>
  
  <script>
    // Order search functionality
    const searchInput = document.getElementById('orderSearch');
    const orderRows = document.querySelectorAll('.orders-table tbody tr');
    
    searchInput.addEventListener('keyup', function() {
      const searchTerm = this.value.toLowerCase();
      
      orderRows.forEach(row => {
        const orderId = row.querySelector('td:nth-child(1)').textContent.toLowerCase();
        const customer = row.querySelector('td:nth-child(2)').textContent.toLowerCase();
        
        if(orderId.includes(searchTerm) || customer.includes(searchTerm)) {
          row.style.display = '';
        } else {
          row.style.display = 'none';
        }
      });
    });
    
    // Modal functionality
    const updateStatusBtns = document.querySelectorAll('.update-status-btn');
    const updatePaymentBtns = document.querySelectorAll('.update-payment-btn');
    const statusModal = document.getElementById('updateStatusModal');
    const paymentModal = document.getElementById('updatePaymentModal');
    const modalCloseBtns = document.querySelectorAll('.modal-close, .modal-close-btn');
    
    updateStatusBtns.forEach(btn => {
      btn.addEventListener('click', function() {
        const orderId = this.getAttribute('data-order-id');
        document.getElementById('statusOrderId').value = orderId;
        statusModal.classList.add('active');
      });
    });
    
    updatePaymentBtns.forEach(btn => {
      btn.addEventListener('click', function() {
        const orderId = this.getAttribute('data-order-id');
        document.getElementById('paymentOrderId').value = orderId;
        paymentModal.classList.add('active');
      });
    });
    
    modalCloseBtns.forEach(btn => {
      btn.addEventListener('click', function() {
        statusModal.classList.remove('active');
        paymentModal.classList.remove('active');
      });
    });
    
    // Close modal when clicking outside
    window.addEventListener('click', function(event) {
      if (event.target === statusModal) {
        statusModal.classList.remove('active');
      }
      if (event.target === paymentModal) {
        paymentModal.classList.remove('active');
      }
    });
  </script>
</body>
</html>

