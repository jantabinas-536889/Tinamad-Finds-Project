<?php
session_start();
include '../config/database.php';
include '../includes/functions.php';

// Check if user is logged in and is admin
if(!isLoggedIn() || !isAdmin()) {
    redirect('../login.php', 'You do not have permission to access this page', 'danger');
}

// Get all products
$products = getProducts($conn);

// Handle product deletion
if(isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $product_id = $_GET['delete'];
    
    $sql = "DELETE FROM products WHERE id = :id";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':id', $product_id, PDO::PARAM_INT);
    
    if($stmt->execute()) {
        redirect('products.php', 'Product deleted successfully', 'success');
    } else {
        redirect('products.php', 'Failed to delete product', 'danger');
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Products - Tinamad Finds Admin</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .admin-container {
            display: grid;
            grid-template-columns: 250px 1fr;
            min-height: 100vh;
        }
        
        .admin-sidebar {
            background-color: #2c3e50;
            color: #fff;
            padding: 20px 0;
        }
        
        .admin-logo {
            padding: 0 20px 20px;
            margin-bottom: 20px;
            border-bottom: 1px solid #3d5166;
            display: flex;
            align-items: center;
        }
        
        .admin-logo h1 {
            font-size: 20px;
            margin-left: 10px;
        }
        
        .admin-menu ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        
        .admin-menu ul li {
            margin-bottom: 5px;
        }
        
        .admin-menu ul li a {
            display: flex;
            align-items: center;
            padding: 12px 20px;
            color: #ecf0f1;
            text-decoration: none;
            transition: background-color 0.3s;
        }
        
        .admin-menu ul li a:hover,
        .admin-menu ul li a.active {
            background-color: #3d5166;
        }
        
        .admin-menu ul li a i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        
        .admin-content {
            padding: 20px;
            background-color: #f5f5f5;
        }
        
        .admin-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }
        
        .admin-header h2 {
            font-size: 24px;
        }
        
        .products-container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        
        .products-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 1px solid #eee;
        }
        
        .products-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .products-table th,
        .products-table td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }
        
        .products-table th {
            background-color: #f9f9f9;
        }
        
        .product-image {
            width: 60px;
            height: 60px;
            border-radius: 4px;
            overflow: hidden;
        }
        
        .product-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .product-actions {
            display: flex;
            gap: 5px;
        }
        
        .product-actions a {
            padding: 5px 10px;
            font-size: 12px;
        }
        
        .featured-badge {
            display: inline-block;
            padding: 3px 8px;
            background-color: #3498db;
            color: #fff;
            border-radius: 4px;
            font-size: 12px;
        }
        
        .stock-low {
            color: #e74c3c;
        }
        
        .stock-medium {
            color: #f39c12;
        }
        
        .stock-high {
            color: #2ecc71;
        }
        
        @media (max-width: 992px) {
            .admin-container {
                grid-template-columns: 1fr;
            }
            
            .admin-sidebar {
                display: none;
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <div class="admin-sidebar">
            <div class="admin-logo">
                <i class="fas fa-tshirt"></i>
                <h1>TinamadFinds Admin</h1>
            </div>
            
            <div class="admin-menu">
                <ul>
                    <li><a href="index.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                    <li><a href="products.php" class="active"><i class="fas fa-box"></i> Products</a></li>
                    <li><a href="orders.php"><i class="fas fa-shopping-cart"></i> Orders</a></li>
                    <li><a href="customers.php"><i class="fas fa-users"></i> Customers</a></li>
                
                    <li><a href="../index.php" target="_blank"><i class="fas fa-external-link-alt"></i> View Store</a></li>
                    <li><a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                </ul>
            </div>
        </div>
        
        <div class="admin-content">
            <div class="admin-header">
                <h2>Manage Products</h2>
                
                <a href="add_product.php" class="btn">Add New Product</a>
            </div>
            
            <div class="products-container">
                <div class="products-header">
                    <h3>All Products</h3>
                    
                    <div class="search-box">
                        <input type="text" id="productSearch" placeholder="Search products...">
                    </div>
                </div>
                
                <?php echo displayMessage(); ?>
                
                <table class="products-table">
                    <thead>
                        <tr>
                            <th>Image</th>
                            <th>Name</th>
                            <th>Price</th>
                            <th>Stock</th>
                            <th>Featured</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($products as $product): ?>
                            <?php
                            $stock_class = '';
                            if($product['stock'] <= 5) {
                                $stock_class = 'stock-low';
                            } elseif($product['stock'] <= 20) {
                                $stock_class = 'stock-medium';
                            } else {
                                $stock_class = 'stock-high';
                            }
                            ?>
                            <tr>
                                <td>
                                    <div class="product-image">
                                        <img src="../assets/images/products/<?php echo htmlspecialchars($product['image']); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>">
                                    </div>
                                </td>
                                <td><?php echo htmlspecialchars($product['name']); ?></td>
                                <td>
                                    <?php if($product['sale_price']): ?>
                                        <span class="original-price">₱<?php echo number_format($product['price'], 2); ?></span>
                                        <span class="sale-price">₱<?php echo number_format($product['sale_price'], 2); ?></span>
                                    <?php else: ?>
                                        ₱<?php echo number_format($product['price'], 2); ?>
                                    <?php endif; ?>
                                </td>
                                <td class="<?php echo $stock_class; ?>"><?php echo $product['stock']; ?></td>
                                <td>
                                    <?php if($product['featured']): ?>
                                        <span class="featured-badge">Featured</span>
                                    <?php else: ?>
                                        -
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="product-actions">
                                        <a href="edit_product.php?id=<?php echo $product['id']; ?>" class="btn btn-sm">Edit</a>
                                        <a href="products.php?delete=<?php echo $product['id']; ?>" class="btn btn-sm btn-outline" onclick="return confirm('Are you sure you want to delete this product?')">Delete</a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <script>
        // Product search functionality
        const searchInput = document.getElementById('productSearch');
        const productRows = document.querySelectorAll('.products-table tbody tr');
        
        searchInput.addEventListener('keyup', function() {
            const searchTerm = this.value.toLowerCase();
            
            productRows.forEach(row => {
                const productName = row.querySelector('td:nth-child(2)').textContent.toLowerCase();
                
                if(productName.includes(searchTerm)) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        });
    </script>
</body>
</html>

