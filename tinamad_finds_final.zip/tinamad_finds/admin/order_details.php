<?php
session_start();
include '../config/database.php';
include '../includes/functions.php';

if(!isLoggedIn() || !isAdmin()) {
  redirect('../login.php', 'You do not have permission to access this page', 'danger');
}

if(!isset($_GET['id']) || !is_numeric($_GET['id'])) {
  redirect('orders.php', 'Invalid order ID', 'danger');
}

$order_id = $_GET['id'];
$order = getOrderById($conn, $order_id);

if(!$order) {
  redirect('orders.php', 'Order not found', 'danger');
}

$order_items = getOrderItems($conn, $order_id);

if(isset($_POST['update_status'])) {
  $status = $_POST['status'];
  
  if(updateOrderStatus($conn, $order_id, $status)) {
    redirect('order_details.php?id=' . $order_id, 'Order status updated successfully', 'success');
  } else {
    redirect('order_details.php?id=' . $order_id, 'Failed to update order status', 'danger');
  }
}

if(isset($_POST['update_payment'])) {
  $payment_status = $_POST['payment_status'];
  
  if(updatePaymentStatus($conn, $order_id, $payment_status)) {
    redirect('order_details.php?id=' . $order_id, 'Payment status updated successfully', 'success');
  } else {
    redirect('order_details.php?id=' . $order_id, 'Failed to update payment status', 'danger');
  }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Order Details - Tinamad Finds Admin</title>
  <link rel="stylesheet" href="../assets/css/style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    .admin-container {
      display: grid;
      grid-template-columns: 250px 1fr;
      min-height: 100vh;
    }

    .admin-sidebar {
      background-color: #2c3e50;
      color: #fff;
      padding: 20px 0;
    }

    .admin-logo {
      padding: 0 20px 20px;
      margin-bottom: 20px;
      border-bottom: 1px solid #3d5166;
      display: flex;
      align-items: center;
    }

    .admin-logo h1 {
      font-size: 20px;
      margin-left: 10px;
    }

    .admin-menu ul {
      list-style: none;
      padding: 0;
      margin: 0;
    }

    .admin-menu ul li {
      margin-bottom: 5px;
    }

    .admin-menu ul li a {
      display: flex;
      align-items: center;
      padding: 12px 20px;
      color: #ecf0f1;
      text-decoration: none;
      transition: background-color 0.3s;
    }

    .admin-menu ul li a:hover,
    .admin-menu ul li a.active {
      background-color: #3d5166;
    }

    .admin-content {
      padding: 20px;
      background-color: #f5f5f5;
    }

    .admin-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 30px;
    }

    .order-card {
      background: #fff;
      padding: 20px;
      border-radius: 8px;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    }

    .order-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 25px;
      padding-bottom: 15px;
      border-bottom: 1px solid #eee;
    }

    .order-table {
      width: 100%;
      border-collapse: collapse;
      margin: 20px 0;
    }

    .order-table th,
    .order-table td {
      padding: 12px 15px;
      text-align: left;
      border-bottom: 1px solid #eee;
    }

    .status-badge {
      display: inline-block;
      padding: 5px 10px;
      border-radius: 20px;
      font-size: 12px;
      font-weight: 700;
      text-transform: uppercase;
    }

    .status-pending { background: #f39c12; color: #fff; }
    .status-processing { background: #3498db; color: #fff; }
    .status-shipped { background: #2ecc71; color: #fff; }
    .status-delivered { background: #27ae60; color: #fff; }
    .status-cancelled { background: #e74c3c; color: #fff; }
    .status-paid { background: #2ecc71; color: #fff; }
    .status-failed { background: #e74c3c; color: #fff; }

    .status-actions {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 20px;
      margin-top: 30px;
    }

    .status-form {
      background: #fff;
      padding: 20px;
      border-radius: 8px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }

    .form-group {
      margin-bottom: 15px;
    }

    select {
      width: 100%;
      padding: 10px;
      border: 1px solid #ddd;
      border-radius: 4px;
      background: #fff;
    }

    .btn {
      padding: 8px 16px;
      border-radius: 4px;
      cursor: pointer;
      transition: 0.3s;
    }

    .btn-outline {
      background: transparent;
      border: 1px solid #4a00e0;
      color: #4a00e0;
    }

    .btn-primary {
      background: #4a00e0;
      color: white;
      border: none;
    }

    .product-image {
      width: 60px;
      height: 60px;
      border-radius: 8px;
      overflow: hidden;
    }

    .product-image img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }

    @media (max-width: 992px) {
      .admin-container {
        grid-template-columns: 1fr;
      }
      .admin-sidebar {
        display: none;
      }
    }
  </style>
</head>
<body>
  <div class="admin-container">
    <div class="admin-sidebar">
      <div class="admin-logo">
        <i class="fas fa-tshirt"></i>
        <h1>TinamadFinds Admin</h1>
      </div>
  <div class="admin-menu">
        <ul>
          <li><a href="index.php"><i class="fas fa-tachometer-alt"></i>  Dashboard</a></li>
          <li><a href="products.php"><i class="fas fa-box"></i>  Products</a></li>
          <li><a href="orders.php" class="active"><i class="fas fa-shopping-cart"></i>  Orders</a></li>
          <li><a href="customers.php"><i class="fas fa-users"></i>  Customers</a></li>
          <li><a href="../index.php" target="_blank"><i class="fas fa-external-link-alt"></i>  View Store</a></li>
          <li><a href="../logout.php"><i class="fas fa-sign-out-alt"></i>  Logout</a></li>
        </ul>
      </div>
    </div>

    <div class="admin-content">
      <div class="admin-header">
        <h2>Order Details</h2>
        <a href="orders.php" class="btn btn-outline">Back to Orders</a>
      </div>
      
      <div class="order-card">
        <div class="order-header">
          <h3>Order #<?php echo $order['id']; ?></h3>
          <span class="text-muted"><?php echo date('M j, Y', strtotime($order['created_at'])); ?></span>
        </div>
        
        <?php echo displayMessage(); ?>
        
        <table class="order-table">
          <tr>
            <th width="30%">Order Information</th>
            <th width="30%">Customer Information</th>
            <th>Shipping Address</th>
          </tr>
          <tr>
            <td>
              <div class="detail-row">
                <div>Order Number:</div>
                <div class="text-bold">#<?php echo $order['id']; ?></div>
              </div>
              <div class="detail-row">
                <div>Order Date:</div>
                <div><?php echo date('M j, Y', strtotime($order['created_at'])); ?></div>
              </div>
              <div class="detail-row">
                <div>Order Status:</div>
                <div class="status-badge status-<?php echo $order['status']; ?>">
                  <?php echo ucfirst($order['status']); ?>
                </div>
              </div>
              <div class="detail-row">
                <div>Payment Status:</div>
                <div class="status-badge status-<?php echo $order['payment_status']; ?>">
                  <?php echo ucfirst($order['payment_status']); ?>
                </div>
              </div>
            </td>
            <td>
              <div class="detail-row">
                <div>Customer:</div>
                <div class="text-bold"><?php echo htmlspecialchars($order['username']); ?></div>
              </div>
              <div class="detail-row">
                <div>Email:</div>
                <div><?php echo htmlspecialchars($order['email']); ?></div>
              </div>
              <div class="detail-row">
                <div>Contact:</div>
                <div><?php echo htmlspecialchars($order['phone'] ?? 'N/A'); ?></div>
              </div>
            </td>
            <td>
              <?php echo nl2br(htmlspecialchars($order['shipping_address'])); ?>
            </td>
          </tr>
        </table>

        <h4 style="margin: 25px 0 15px;">Order Items</h4>
        <table class="order-table">
          <thead>
            <tr>
              <th>Product</th>
              <th>Price</th>
              <th>Quantity</th>
              <th>Total</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach($order_items as $item): ?>
              <tr>
                <td>
                  <div class="product-info">
                    <div class="product-image">
                      <img src="../assets/images/products/<?php echo htmlspecialchars($item['image']); ?>" alt="<?php echo htmlspecialchars($item['name']); ?>">
                    </div>
                    <div>
                      <h4><?php echo htmlspecialchars($item['name']); ?></h4>
                      <small>SKU: <?php echo $item['sku'] ?? 'N/A'; ?></small>
                    </div>
                  </div>
                </td>
                <td>₱<?php echo number_format($item['price'], 2); ?></td>
                <td><?php echo $item['quantity']; ?></td>
                <td>₱<?php echo number_format($item['price'] * $item['quantity'], 2); ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>

        <div class="order-summary" style="margin-top: 20px; text-align: right;">
          <div style="display: inline-block; width: 300px;">
            <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
              <span>Subtotal:</span>
              <span>₱<?php echo number_format($order['total_amount'], 2); ?></span>
            </div>
            <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
              <span>Shipping:</span>
              <span>Free</span>
            </div>
            <div style="display: flex; justify-content: space-between; font-weight: bold;">
              <span>Total:</span>
              <span>₱<?php echo number_format($order['total_amount'], 2); ?></span>
            </div>
          </div>
        </div>

        <div class="status-actions">
          <div class="status-form">
            <h4>Update Order Status</h4>
            <form action="order_details.php?id=<?php echo $order_id; ?>" method="post">
              <div class="form-group">
                <select id="status" name="status" required>
                  <option value="pending" <?= $order['status'] === 'pending' ? 'selected' : '' ?>>Pending</option>
                  <option value="processing" <?= $order['status'] === 'processing' ? 'selected' : '' ?>>Processing</option>
                  <option value="shipped" <?= $order['status'] === 'shipped' ? 'selected' : '' ?>>Shipped</option>
                  <option value="delivered" <?= $order['status'] === 'delivered' ? 'selected' : '' ?>>Delivered</option>
                  <option value="cancelled" <?= $order['status'] === 'cancelled' ? 'selected' : '' ?>>Cancelled</option>
                </select>
              </div>
              <button type="submit" name="update_status" class="btn btn-primary">Update Status</button>
            </form>
          </div>

          <div class="status-form">
            <h4>Update Payment Status</h4>
            <form action="order_details.php?id=<?php echo $order_id; ?>" method="post">
              <div class="form-group">
                <select id="payment_status" name="payment_status" required>
                  <option value="pending" <?= $order['payment_status'] === 'pending' ? 'selected' : '' ?>>Pending</option>
                  <option value="paid" <?= $order['payment_status'] === 'paid' ? 'selected' : '' ?>>Paid</option>
                  <option value="failed" <?= $order['payment_status'] === 'failed' ? 'selected' : '' ?>>Failed</option>
                </select>
              </div>
              <button type="submit" name="update_payment" class="btn btn-primary">Update Payment</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</body>
</html>