<?php
session_start();
include '../config/database.php';
include '../includes/functions.php';

// Check if user is logged in and is admin
if(!isLoggedIn() || !isAdmin()) {
  header('HTTP/1.1 403 Forbidden');
  echo json_encode(['error' => 'Access denied']);
  exit;
}

// Check if customer ID is provided
if(!isset($_GET['id']) || !is_numeric($_GET['id'])) {
  header('HTTP/1.1 400 Bad Request');
  echo json_encode(['error' => 'Invalid customer ID']);
  exit;
}

$customer_id = $_GET['id'];

// Get customer details
$sql = "SELECT * FROM users WHERE id = :id AND role = 'customer'";
$stmt = $conn->prepare($sql);
$stmt->bindParam(':id', $customer_id, PDO::PARAM_INT);
$stmt->execute();
$customer = $stmt->fetch();

if(!$customer) {
  header('HTTP/1.1 404 Not Found');
  echo json_encode(['error' => 'Customer not found']);
  exit;
}

// Return customer details as JSON
header('Content-Type: application/json');
echo json_encode($customer);
?>

