<?php
session_start();
include '../config/database.php';
include '../includes/functions.php';

// Check if user is logged in and is admin
if(!isLoggedIn() || !isAdmin()) {
    redirect('../login.php', 'You do not have permission to access this page', 'danger');
}

$errors = [];

// Process form submission
if($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate input
    $name = trim($_POST['name']);
    $description = trim($_POST['description']);
    $price = trim($_POST['price']);
    $sale_price = !empty($_POST['sale_price']) ? trim($_POST['sale_price']) : null;
    $stock = $_POST['stock'];
    $featured = isset($_POST['featured']) ? 1 : 0;
    
    if(empty($name)) {
        $errors[] = 'Product name is required';
    }
    
    if(empty($price) || !is_numeric($price) || $price <= 0) {
        $errors[] = 'Valid price is required';
    }
    
    if(!empty($sale_price) && (!is_numeric($sale_price) || $sale_price <= 0 || $sale_price >= $price)) {
        $errors[] = 'Sale price must be less than regular price';
    }
    
    if(!is_numeric($stock) || $stock < 0) {
        $errors[] = 'Valid stock quantity is required';
    }
    
    // Handle image upload
    $image = 'placeholder.jpg'; // Default image

    if(isset($_FILES['image']) && $_FILES['image']['error'] === 0) {
        $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
        $max_size = 2 * 1024 * 1024; // 2MB
        
        if(!in_array($_FILES['image']['type'], $allowed_types)) {
            $errors[] = 'Only JPG, PNG, and GIF images are allowed';
        } elseif($_FILES['image']['size'] > $max_size) {
            $errors[] = 'Image size must be less than 2MB';
        } else {
            // Create directory if it doesn't exist
            $upload_dir = '../assets/images/products/';
            if (!file_exists($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }
            
            $extension = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
            $filename = uniqid() . '.' . $extension;
            $destination = $upload_dir . $filename;
            
            if(move_uploaded_file($_FILES['image']['tmp_name'], $destination)) {
                $image = $filename;
            } else {
                $errors[] = 'Failed to upload image. Please check directory permissions.';
            }
        }
    }
    
    // If no errors, add product
    if(empty($errors)) {
        $sql = "INSERT INTO products (name, description, price, sale_price, stock, featured, image) 
                VALUES (:name, :description, :price, :sale_price, :stock, :featured, :image)";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':name', $name);
        $stmt->bindParam(':description', $description);
        $stmt->bindParam(':price', $price);
        $stmt->bindParam(':sale_price', $sale_price);
        $stmt->bindParam(':stock', $stock);
        $stmt->bindParam(':featured', $featured);
        $stmt->bindParam(':image', $image);
        
        if($stmt->execute()) {
            redirect('products.php', 'Product added successfully', 'success');
        } else {
            $errors[] = 'Failed to add product';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">  
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Product - Tinamad Finds Admin</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .admin-container {
            display: grid;
            grid-template-columns: 250px 1fr;
            min-height: 100vh;
        }
        
        .admin-sidebar {
            background-color: #2c3e50;
            color: #fff;
            padding: 20px 0;
        }
        
        .admin-logo {
            padding: 0 20px 20px;
            margin-bottom: 20px;
            border-bottom: 1px solid #3d5166;
            display: flex;
            align-items: center;
        }
        
        .admin-logo h1 {
            font-size: 20px;
            margin-left: 10px;
        }
        
        .admin-menu ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        
        .admin-menu ul li {
            margin-bottom: 5px;
        }
        
        .admin-menu ul li a {
            display: flex;
            align-items: center;
            padding: 12px 20px;
            color: #ecf0f1;
            text-decoration: none;
            transition: background-color 0.3s;
        }
        
        .admin-menu ul li a:hover,
        .admin-menu ul li a.active {
            background-color: #3d5166;
        }
        
        .admin-menu ul li a i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        
        .admin-content {
            padding: 20px;
            background-color: #f5f5f5;
        }
        
        .admin-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }
        
        .admin-header h2 {
            font-size: 24px;
        }
        
        .product-form-container {
            background-color: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: 500;
        }
        
        .form-group input[type="text"],
        .form-group input[type="number"],
        .form-group textarea,
        .form-group select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        
        .form-group textarea {
            height: 150px;
            resize: vertical;
        }
        
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }
        
        .checkbox-group {
            display: flex;
            align-items: center;
        }
        
        .checkbox-group input[type="checkbox"] {
            margin-right: 10px;
        }
        
        .error-list {
            background-color: #f8d7da;
            color: #721c24;
            padding: 15px;
            border-radius: 4px;
            margin-bottom: 20px;
        }
        
        .error-list ul {
            margin-left: 20px;
            list-style-type: disc;
        }
        
        @media (max-width: 992px) {
            .admin-container {
                grid-template-columns: 1fr;
            }
            
            .admin-sidebar {
                display: none;
            }
            
            .form-row {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <div class="admin-sidebar">
            <div class="admin-logo">
                <i class="fas fa-tshirt"></i>
                <h1>Tinamad Finds Admin</h1>
            </div>
            
            <div class="admin-menu">
                <ul>
                    <li><a href="index.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                    <li><a href="products.php" class="active"><i class="fas fa-box"></i> Products</a></li>
                    <li><a href="orders.php"><i class="fas fa-shopping-cart"></i> Orders</a></li>
                    <li><a href="customers.php"><i class="fas fa-users"></i> Customers</a></li>
                    <li><a href="../index.php" target="_blank"><i class="fas fa-external-link-alt"></i> View Store</a></li>
                    <li><a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                </ul>
            </div>
        </div>
        
        <div class="admin-content">
            <div class="admin-header">
                <h2>Add New Product</h2>
                
                <a href="products.php" class="btn btn-outline">Back to Products</a>
            </div>
            
            <div class="product-form-container">
                <?php if(!empty($errors)): ?>
                    <div class="error-list">
                        <ul>
                            <?php foreach($errors as $error): ?>
                                <li><?php echo $error; ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>
                
                <form action="add_product.php" method="post" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="name">Product Name</label>
                        <input type="text" id="name" name="name" value="<?php echo isset($_POST['name']) ? htmlspecialchars($_POST['name']) : ''; ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="description">Description</label>
                        <textarea id="description" name="description"><?php echo isset($_POST['description']) ? htmlspecialchars($_POST['description']) : ''; ?></textarea>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="price">Price (₱)</label>
                            <input type="number" id="price" name="price" step="0.01" min="0" value="<?php echo isset($_POST['price']) ? htmlspecialchars($_POST['price']) : ''; ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="sale_price">Sale Price (₱) (optional)</label>
                            <input type="number" id="sale_price" name="sale_price" step="0.01" min="0" value="<?php echo isset($_POST['sale_price']) ? htmlspecialchars($_POST['sale_price']) : ''; ?>">
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="stock">Stock Quantity</label>
                            <input type="number" id="stock" name="stock" min="0" value="<?php echo isset($_POST['stock']) ? htmlspecialchars($_POST['stock']) : '1'; ?>" required>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="image">Product Image</label>
                        <input type="file" id="image" name="image">
                        <small>Recommended size: 800x800 pixels. Max size: 2MB.</small>
                    </div>
                    
                    <div class="form-group checkbox-group">
                        <input type="checkbox" id="featured" name="featured" <?php echo isset($_POST['featured']) ? 'checked' : ''; ?>>
                        <label for="featured">Featured Product</label>
                    </div>
                    
                    <div class="form-group">
                        <button type="submit" class="btn">Add Product</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>