<?php
// Create users table
$sql = "CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    address TEXT,
    city VARCHAR(50),
    postal_code VARCHAR(20),
    country VARCHAR(50),
    phone VARCHAR(20),
    role ENUM('customer', 'admin') DEFAULT 'customer',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";
$conn->exec($sql);

// Create categories table
$sql = "CREATE TABLE IF NOT EXISTS categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    image VARCHAR(255)
)";
$conn->exec($sql);

// Create products table
$sql = "CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category_id INT,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    price DECIMAL(10,2) NOT NULL,
    sale_price DECIMAL(10,2),
    image VARCHAR(255),
    stock INT NOT NULL DEFAULT 0,
    featured BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL
)";
$conn->exec($sql);

// Create orders table
$sql = "CREATE TABLE IF NOT EXISTS orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    total_amount DECIMAL(10,2) NOT NULL,
    status ENUM('pending', 'processing', 'shipped', 'delivered', 'cancelled') DEFAULT 'pending',
    payment_status ENUM('pending', 'paid', 'failed') DEFAULT 'pending',
    shipping_address TEXT,
    billing_address TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
)";
$conn->exec($sql);

// Create order_items table
$sql = "CREATE TABLE IF NOT EXISTS order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT,
    product_id INT,
    quantity INT NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL
)";
$conn->exec($sql);

// Create cart table
$sql = "CREATE TABLE IF NOT EXISTS cart (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    product_id INT,
    quantity INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
)";
$conn->exec($sql);

// Insert default admin user
$admin_password = password_hash('admin123', PASSWORD_DEFAULT);
$sql = "INSERT INTO users (username, email, password, role) 
        VALUES ('admin', 'admin@tinamadfinds.com', :password, 'admin')
        ON DUPLICATE KEY UPDATE id=id";
$stmt = $conn->prepare($sql);
$stmt->bindParam(':password', $admin_password);
$stmt->execute();

// Insert sample categories
$categories = [
    ['Men', 'Men\'s clothing collection', 'men_category.jpg'],
    ['Women', 'Women\'s clothing collection', 'women_category.jpg'],
    ['Accessories', 'Fashion accessories', 'accessories_category.jpg']
];

$sql = "INSERT INTO categories (name, description, image) VALUES (:name, :description, :image)";
$stmt = $conn->prepare($sql);

foreach ($categories as $category) {
    $stmt->bindParam(':name', $category[0]);
    $stmt->bindParam(':description', $category[1]);
    $stmt->bindParam(':image', $category[2]);
    $stmt->execute();
}

// Insert sample products
$products = [
    [1, 'Burberry LongSleeve', 'Burberry Long Sleeve (Size: Large)
Dimensions: 22x29
Color Rate: 9.5/10
Condition: 9.5/10
Timeless design, premium fabric, excellent condition with no flaws', 29.99, NULL, 'thrift1.jpg', 50, 1],
    [1, 'Bape Tee', 'BAPE Tee (Size: Large)
Dimensions: 22x28
Color Rate: 9.5/10
Condition: 9.5/10
High-quality cotton, iconic graphic print, excellent condition with no visible flaws', 59.99, 49.99, 'bape.jpg', 30, 1],
    [2, 'Nasa Tee', 'NASA Tee (Size: Medium)
Dimensions: 21x27
Color Rate: 9/10
Condition: 9/10
Slight fading on print, overall in great condition', 79.99, NULL, 'nasa.jpg', 25, 1],
    [2, 'Aape Tee', 'AAPE Black Tee (Size: Large)
Dimensions: 22x28
Color Rate: 9.5/10
Condition: 9.5/10
Excellent condition, no flaws or issues', 39.99, 34.99, 'aape.jpg', 40, 0],
];

$sql = "INSERT INTO products (category_id, name, description, price, sale_price, image, stock, featured) 
        VALUES (:category_id, :name, :description, :price, :sale_price, :image, :stock, :featured)";
$stmt = $conn->prepare($sql);

foreach ($products as $product) {
    $stmt->bindParam(':category_id', $product[0]);
    $stmt->bindParam(':name', $product[1]);
    $stmt->bindParam(':description', $product[2]);
    $stmt->bindParam(':price', $product[3]);
    $stmt->bindParam(':sale_price', $product[4]);
    $stmt->bindParam(':image', $product[5]);
    $stmt->bindParam(':stock', $product[6]);
    $stmt->bindParam(':featured', $product[7]);
    $stmt->execute();
}

echo "Database setup completed successfully!";
?>

