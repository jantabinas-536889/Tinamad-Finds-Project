<?php
session_start();
include 'config/database.php';
include 'includes/functions.php';

// Check if product ID is provided
if(!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    redirect('shop.php', 'Invalid product ID', 'danger');
}

$product_id = $_GET['id'];
$product = getProductById($conn, $product_id);

// Check if product exists
if(!$product) {
    redirect('shop.php', 'Product not found', 'danger');
}

// Get related products (4 random products excluding the current one)
$related_products = [];
try {
    $stmt = $conn->prepare("SELECT * FROM products WHERE id != ? ORDER BY RAND() LIMIT 4");
    $stmt->execute([$product_id]);
    $related_products = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    // If there's an error, we'll just show no related products rather than failing
    $related_products = [];
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($product['name']); ?> - Nova Wear</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <style>
        .product-details {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 40px;
            margin: 40px 0;
        }
        
        .product-gallery {
            display: flex;
            flex-direction: column;
        }
        
        .product-main-image {
            margin-bottom: 20px;
            border-radius: 8px;
            overflow: hidden;
        }
        
        .product-main-image img {
            width: 100%;
            height: auto;
            object-fit: cover;
        }
        
        .product-thumbnails {
            display: flex;
            gap: 10px;
        }
        
        .product-thumbnails img {
            width: 80px;
            height: 80px;
            object-fit: cover;
            border-radius: 4px;
            cursor: pointer;
            border: 2px solid transparent;
            transition: border-color 0.3s ease;
        }
        
        .product-thumbnails img.active,
        .product-thumbnails img:hover {
            border-color: #4a00e0;
        }
        
        .product-info h1 {
            font-size: 32px;
            margin-bottom: 10px;
        }
        
        .product-price {
            font-size: 24px;
            font-weight: 700;
            color: #4a00e0;
            margin-bottom: 20px;
        }
        
        .product-price.sale {
            color: #e53935;
        }
        
        .product-price .original {
            text-decoration: line-through;
            color: #999;
            font-size: 18px;
            margin-right: 10px;
        }
        
        .product-description {
            margin-bottom: 30px;
            line-height: 1.8;
        }
        
        .product-meta {
            margin-bottom: 30px;
        }
        
        .product-meta p {
            margin-bottom: 10px;
        }
        
        .product-meta span {
            font-weight: 700;
        }
        
        .quantity-control {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .quantity-control button {
            width: 40px;
            height: 40px;
            background-color: #f5f5f5;
            border: 1px solid #ddd;
            font-size: 18px;
            cursor: pointer;
        }
        
        .quantity-control input {
            width: 60px;
            height: 40px;
            text-align: center;
            border: 1px solid #ddd;
            border-left: none;
            border-right: none;
        }
        
        .product-actions {
            display: flex;
            gap: 10px;
        }
        
        .related-products {
            margin: 60px 0;
        }
        
        .related-products h2 {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .product-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 20px;
        }
        
        .out-of-stock {
            color: #e53935;
            font-weight: 500;
        }
        
        @media (max-width: 768px) {
            .product-details {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <main class="container">
        <div class="product-details">
            <div class="product-gallery">
                <div class="product-main-image">
                    <img src="assets/images/products/<?php echo !empty($product['image']) ? htmlspecialchars($product['image']) : 'thrift1.jpg'; ?>" alt="<?php echo htmlspecialchars($product['name']); ?>" class="active">
                </div>
                
                <div class="product-thumbnails">
                    <img src="assets/images/products/<?php echo !empty($product['image']) ? htmlspecialchars($product['image']) : 'thrift1.jpg'; ?>" alt="Thrifted Product" class="active">
                    <!-- Additional thumbnails would be here in a real application -->
                </div>
            </div>
            
            <div class="product-info">
                <h1><?php echo htmlspecialchars($product['name']); ?></h1>
                
                <?php if($product['sale_price']): ?>
                    <div class="product-price sale">
                        <span class="original">₱<?php echo number_format($product['price'], 2); ?></span>
                        ₱<?php echo number_format($product['sale_price'], 2); ?>
                    </div>
                <?php else: ?>
                    <div class="product-price">
                        ₱<?php echo number_format($product['price'], 2); ?>
                    </div>
                <?php endif; ?>
                
                <div class="product-description">
                    <p><?php echo nl2br(htmlspecialchars($product['description'])); ?></p>
                </div>
                
                <div class="product-meta">
                    <p><span>Availability:</span> <?php echo $product['stock'] > 0 ? 'In Stock' : 'Out of Stock'; ?></p>
                </div>
                
                <?php if($product['stock'] > 0): ?>
                    <form action="cart_actions.php" method="post">
                        <input type="hidden" name="action" value="add">
                        <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                        
                        <div class="quantity-control">
                            <button type="button" class="decrement">-</button>
                            <input type="number" name="quantity" value="1" min="1" max="<?php echo $product['stock']; ?>" class="quantity-input">
                            <button type="button" class="increment">+</button>
                        </div>
                        
                        <div class="product-actions">
                            <button type="submit" class="btn">Add to Cart</button>
                            <button type="button" class="btn btn-outline">Add to Wishlist</button>
                        </div>
                    </form>
                <?php else: ?>
                    <p class="out-of-stock">This product is currently out of stock.</p>
                <?php endif; ?>
            </div>
        </div>
        
        <?php if(!empty($related_products)): ?>
            <div class="related-products">
                <h2>Related Products</h2>
                
                <div class="product-grid">
                    <?php foreach($related_products as $related): ?>
                        <div class="product-card">
                            <a href="product.php?id=<?php echo $related['id']; ?>">
                                <div class="product-image">
                                    <img src="assets/images/products/<?php echo !empty($related['image']) ? htmlspecialchars($related['image']) : 'thrift1.jpg'; ?>" alt="<?php echo htmlspecialchars($related['name']); ?>">
                                </div>
                                <div class="product-info">
                                    <h3><?php echo htmlspecialchars($related['name']); ?></h3>
                                    <div class="product-price">
                                        <?php if($related['sale_price']): ?>
                                            <span class="sale-price">₱<?php echo number_format($related['sale_price'], 2); ?></span>
                                            <span class="original-price">₱<?php echo number_format($related['price'], 2); ?></span>
                                        <?php else: ?>
                                            <span>₱<?php echo number_format($related['price'], 2); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>
    </main>
    
    <?php include 'includes/footer.php'; ?>
    <script src="assets/js/main.js"></script>
    <script>
        // Quantity control functionality
        document.querySelectorAll('.increment').forEach(button => {
            button.addEventListener('click', () => {
                const input = button.parentElement.querySelector('.quantity-input');
                if(parseInt(input.value) < parseInt(input.max)) {
                    input.value = parseInt(input.value) + 1;
                }
            });
        });
        
        document.querySelectorAll('.decrement').forEach(button => {
            button.addEventListener('click', () => {
                const input = button.parentElement.querySelector('.quantity-input');
                if(parseInt(input.value) > parseInt(input.min)) {
                    input.value = parseInt(input.value) - 1;
                }
            });
        });
    </script>
</body>
</html>