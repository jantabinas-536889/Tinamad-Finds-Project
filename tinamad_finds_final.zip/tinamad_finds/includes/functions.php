<?php
// Get all products
function getProducts($conn, $limit = null) {
    $sql = "SELECT * FROM products";
    if ($limit) {
        $sql .= " LIMIT " . intval($limit);
    }
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    return $stmt->fetchAll();
}

// Get featured products
function getFeaturedProducts($conn, $limit = 4) {
    $sql = "SELECT * FROM products WHERE featured = 1";
    if ($limit) {
        $sql .= " LIMIT " . intval($limit);
    }
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    return $stmt->fetchAll();
}

// Get product by ID
function getProductById($conn, $id) {
    $sql = "SELECT * FROM products WHERE id = :id";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetch();
}

// Get user by ID
function getUserById($conn, $id) {
    $sql = "SELECT * FROM users WHERE id = :id";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetch();
}

// Get user by email
function getUserByEmail($conn, $email) {
    $sql = "SELECT * FROM users WHERE email = :email";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':email', $email);
    $stmt->execute();
    return $stmt->fetch();
}

// Get user by username
function getUserByUsername($conn, $username) {
    $sql = "SELECT * FROM users WHERE username = :username";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':username', $username);
    $stmt->execute();
    return $stmt->fetch();
}

// Get cart items for a user
function getCartItems($conn, $user_id) {
    $sql = "SELECT c.id as cart_id, c.quantity, p.* 
            FROM cart c 
            JOIN products p ON c.product_id = p.id 
            WHERE c.user_id = :user_id";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll();
}

// Get cart total for a user
function getCartTotal($conn, $user_id) {
    $sql = "SELECT SUM(c.quantity * COALESCE(p.sale_price, p.price)) as total 
            FROM cart c 
            JOIN products p ON c.product_id = p.id 
            WHERE c.user_id = :user_id";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $stmt->execute();
    $result = $stmt->fetch();
    return $result['total'] ? $result['total'] : 0;
}

// Add item to cart
function addToCart($conn, $user_id, $product_id, $quantity = 1) {
    $sql = "SELECT * FROM cart WHERE user_id = :user_id AND product_id = :product_id";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $stmt->bindParam(':product_id', $product_id, PDO::PARAM_INT);
    $stmt->execute();
    $existing = $stmt->fetch();
    
    if ($existing) {
        $new_quantity = $existing['quantity'] + $quantity;
        $sql = "UPDATE cart SET quantity = :quantity WHERE id = :id";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':quantity', $new_quantity, PDO::PARAM_INT);
        $stmt->bindParam(':id', $existing['id'], PDO::PARAM_INT);
        return $stmt->execute();
    } else {
        $sql = "INSERT INTO cart (user_id, product_id, quantity) VALUES (:user_id, :product_id, :quantity)";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
        $stmt->bindParam(':product_id', $product_id, PDO::PARAM_INT);
        $stmt->bindParam(':quantity', $quantity, PDO::PARAM_INT);
        return $stmt->execute();
    }
}

// Update cart item quantity
function updateCartItem($conn, $cart_id, $quantity) {
    $sql = "UPDATE cart SET quantity = :quantity WHERE id = :id";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':quantity', $quantity, PDO::PARAM_INT);
    $stmt->bindParam(':id', $cart_id, PDO::PARAM_INT);
    return $stmt->execute();
}

// Remove item from cart
function removeFromCart($conn, $cart_id) {
    $sql = "DELETE FROM cart WHERE id = :id";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':id', $cart_id, PDO::PARAM_INT);
    return $stmt->execute();
}

// Clear user's cart
function clearCart($conn, $user_id) {
    $sql = "DELETE FROM cart WHERE user_id = :user_id";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    return $stmt->execute();
}

// Create a new order
function createOrder($conn, $user_id, $total_amount, $shipping_address, $billing_address) {
    $sql = "INSERT INTO orders (user_id, total_amount, shipping_address, billing_address) 
            VALUES (:user_id, :total_amount, :shipping_address, :billing_address)";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $stmt->bindParam(':total_amount', $total_amount);
    $stmt->bindParam(':shipping_address', $shipping_address);
    $stmt->bindParam(':billing_address', $billing_address);
    $stmt->execute();
    return $conn->lastInsertId();
}

// Add items to an order
function addOrderItems($conn, $order_id, $cart_items) {
    $sql = "INSERT INTO order_items (order_id, product_id, quantity, price) 
            VALUES (:order_id, :product_id, :quantity, :price)";
    $stmt = $conn->prepare($sql);
    
    foreach ($cart_items as $item) {
        $price = $item['sale_price'] ? $item['sale_price'] : $item['price'];
        $stmt->bindParam(':order_id', $order_id, PDO::PARAM_INT);
        $stmt->bindParam(':product_id', $item['id'], PDO::PARAM_INT);
        $stmt->bindParam(':quantity', $item['quantity'], PDO::PARAM_INT);
        $stmt->bindParam(':price', $price);
        $stmt->execute();
        
        updateProductStock($conn, $item['id'], $item['stock'] - $item['quantity']);
    }
    
    return true;
}

// Update product stock
function updateProductStock($conn, $product_id, $new_stock) {
    $sql = "UPDATE products SET stock = :stock WHERE id = :id";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':stock', $new_stock, PDO::PARAM_INT);
    $stmt->bindParam(':id', $product_id, PDO::PARAM_INT);
    return $stmt->execute();
}

// Get orders for a user
function getUserOrders($conn, $user_id) {
    $sql = "SELECT * FROM orders WHERE user_id = :user_id ORDER BY created_at DESC";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll();
}

// Get all orders (for admin)
function getAllOrders($conn, $limit = null, $offset = 0) {
    $sql = "SELECT o.*, u.username, u.email 
            FROM orders o 
            LEFT JOIN users u ON o.user_id = u.id 
            ORDER BY o.created_at DESC";
    
    if ($limit) {
        $sql .= " LIMIT " . intval($offset) . ", " . intval($limit);
    }
    
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    return $stmt->fetchAll();
}

// Get order by ID
function getOrderById($conn, $order_id) {
    $sql = "SELECT o.*, u.username, u.email, u.first_name, u.last_name 
            FROM orders o 
            LEFT JOIN users u ON o.user_id = u.id 
            WHERE o.id = :id";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':id', $order_id, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetch();
}

// Get order items
function getOrderItems($conn, $order_id) {
    $sql = "SELECT oi.*, p.name, p.image 
            FROM order_items oi 
            LEFT JOIN products p ON oi.product_id = p.id 
            WHERE oi.order_id = :order_id";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':order_id', $order_id, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll();
}

// Update order status
function updateOrderStatus($conn, $order_id, $status) {
    $sql = "UPDATE orders SET status = :status WHERE id = :id";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':status', $status);
    $stmt->bindParam(':id', $order_id, PDO::PARAM_INT);
    return $stmt->execute();
}

// Update payment status
function updatePaymentStatus($conn, $order_id, $status) {
    $sql = "UPDATE orders SET payment_status = :status WHERE id = :id";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':status', $status);
    $stmt->bindParam(':id', $order_id, PDO::PARAM_INT);
    return $stmt->execute();
}

// HTML for product card
function productCard($product) {
    $price_html = $product['sale_price'] 
        ? '<span class="price sale"><span class="original">₱' . number_format($product['price'], 2) . '</span> ₱' . number_format($product['sale_price'], 2) . '</span>'
        : '<span class="price">₱' . number_format($product['price'], 2) . '</span>';
    
    return '
    <div class="product-card">
        <div class="product-image">
            <img src="assets/images/products/' . htmlspecialchars($product['image']) . '" alt="' . htmlspecialchars($product['name']) . '">
        </div>
        <div class="product-info">
            <h3>' . htmlspecialchars($product['name']) . '</h3>
            ' . $price_html . '
        </div>
        <div class="product-actions">
            <a href="product.php?id=' . $product['id'] . '" class="btn btn-secondary">View Details</a>
            <form action="cart_actions.php" method="post">
                <input type="hidden" name="action" value="add">
                <input type="hidden" name="product_id" value="' . $product['id'] . '">
                <button type="submit" class="btn btn-primary">Add to Cart</button>
            </form>
        </div>
    </div>';
}

// Check if user is logged in
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

// Check if user is admin
function isAdmin() {
    return isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
}

// Redirect with message
function redirect($url, $message = null, $message_type = null) {
    if ($message) {
        $_SESSION['message'] = $message;
        $_SESSION['message_type'] = $message_type;
    }
    header('Location: ' . $url);
    exit;
}

// Display message
function displayMessage() {
    if (isset($_SESSION['message'])) {
        $message_type = isset($_SESSION['message_type']) ? $_SESSION['message_type'] : 'info';
        $output = '<div class="alert alert-' . $message_type . '">' . $_SESSION['message'] . '</div>';
        unset($_SESSION['message']);
        unset($_SESSION['message_type']);
        return $output;
    }
    return '';
}

// Sanitize input
function sanitize($input) {
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}
?>
