<header class="site-header">
  <div class="container">
      <div class="header-wrapper">
          <div class="logo">
              <a href="index.php">
                  <h1>Tinamad Finds</h1>
              </a>
          </div>
          
          <nav class="main-nav">
              <ul>
                  <li><a href="index.php">Home</a></li>
                  <li><a href="shop.php">Shop</a></li>
                  <li><a href="about.php">About</a></li>
                  <li><a href="contact.php">Contact</a></li>
              </ul>
          </nav>
          
          <div class="header-actions">
              <a href="cart.php" class="cart-icon">
                  <i class="fas fa-shopping-cart"></i>
                  <?php
                  if(isLoggedIn()) {
                      $cart_items = getCartItems($conn, $_SESSION['user_id']);
                      $cart_count = 0;
                      foreach($cart_items as $item) {
                          $cart_count += $item['quantity'];
                      }
                      if($cart_count > 0) {
                          echo '<span class="cart-count">' . $cart_count . '</span>';
                      }
                  }
                  ?>
              </a>
              
              <?php if(isLoggedIn()): ?>
                  <div class="user-menu">
                      <button class="user-menu-btn">
                          <i class="fas fa-user"></i>
                          <span><?php echo $_SESSION['username']; ?></span>
                      </button>
                      <div class="user-dropdown">
                          <a href="account.php">My Account</a>
                          <a href="orders.php">My Orders</a>
                          <?php if(isAdmin()): ?>
                              <a href="admin/index.php">Admin Dashboard</a>
                          <?php endif; ?>
                          <a href="logout.php">Logout</a>
                      </div>
                  </div>
              <?php else: ?>
                  <div class="auth-buttons">
                      <a href="login.php" class="btn btn-outline">Login</a>
                      <a href="register.php" class="btn">Register</a>
                  </div>
              <?php endif; ?>
              
              <button class="mobile-menu-toggle">
                  <i class="fas fa-bars"></i>
              </button>
          </div>
      </div>
  </div>
</header>

<div class="mobile-menu">
  <div class="container">
      <ul>
          <li><a href="index.php">Home</a></li>
          <li><a href="shop.php">Shop</a></li>
          <li><a href="about.php">About</a></li>
          <li><a href="contact.php">Contact</a></li>
          
          <?php if(isLoggedIn()): ?>
              <li><a href="account.php">My Account</a></li>
              <li><a href="orders.php">My Orders</a></li>
              <?php if(isAdmin()): ?>
                  <li><a href="admin/index.php">Admin Dashboard</a></li>
              <?php endif; ?>
              <li><a href="logout.php">Logout</a></li>
          <?php else: ?>
              <li><a href="login.php">Login</a></li>
              <li><a href="register.php">Register</a></li>
          <?php endif; ?>
      </ul>
  </div>
</div>

<?php echo displayMessage(); ?>
