<?php
session_start();
include 'config/database.php';
include 'includes/functions.php';

// Get all products
$products = getProducts($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shop - Tinamad Finds</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        .shop-container {
            display: grid;
            grid-template-columns: 250px 1fr;
            gap: 30px;
            margin: 40px 0;
        }

        .filters {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            align-self: start;
        }

        .filters h3 {
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 1px solid #eee;
        }

        .filter-group {
            margin-bottom: 20px;
        }

        .filter-group h4 {
            margin-bottom: 10px;
        }

        .filter-options label {
            display: block;
            margin-bottom: 8px;
        }

        .price-range {
            display: flex;
            gap: 10px;
            align-items: center;
        }

        .price-range input {
            width: 80px;
            padding: 5px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }

        .shop-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .sort-options {
            display: flex;
            align-items: center;
        }

        .sort-options label {
            margin-right: 10px;
        }

        .sort-options select {
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }

        .mobile-filter-toggle {
            display: none;
            margin-bottom: 20px;
        }

        @media (max-width: 768px) {
            .shop-container {
                grid-template-columns: 1fr;
            }

            .filters {
                display: none;
            }

            .filters.active {
                display: block;
            }

            .mobile-filter-toggle {
                display: block;
            }
        }
    </style>
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <main class="container">
        <h1 class="page-title">Shop All Products</h1>

        <button class="btn mobile-filter-toggle">
            <i class="fas fa-filter"></i> Show Filters
        </button>

        <div class="shop-container">
            <div class="filters">
                <h3>Filter Products</h3>

                <form action="shop.php" method="get">
                    <div class="filter-group">
                        <h4>Price Range</h4>
                        <div class="filter-options">
                            <div class="price-range">
                                <input type="number" name="min_price" placeholder="Min" min="0">
                                <span>to</span>
                                <input type="number" name="max_price" placeholder="Max" min="0">
                            </div>
                        </div>
                    </div>

                    <div class="filter-group">
                        <h4>Availability</h4>
                        <div class="filter-options">
                            <label>
                                <input type="checkbox" name="in_stock" value="1">
                                In Stock Only
                            </label>
                        </div>
                    </div>

                    <button type="submit" class="btn">Apply Filters</button>
                </form>
            </div>

            <div class="products-section">
                <div class="shop-header">
                    <p><span><?php echo count($products); ?></span> products found</p>

                    <div class="sort-options">
                        <label for="sort">Sort by:</label>
                        <select id="sort" name="sort">
                            <option value="newest">Newest</option>
                            <option value="price_low">Price: Low to High</option>
                            <option value="price_high">Price: High to Low</option>
                            <option value="name_asc">Name: A to Z</option>
                            <option value="name_desc">Name: Z to A</option>
                        </select>
                    </div>
                </div>

                <div class="product-grid">
                    <?php foreach($products as $product): ?>
                        <?php echo productCard($product); ?>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </main>

    <?php include 'includes/footer.php'; ?>
    <script src="assets/js/main.js"></script>
    <script>
        // Mobile filter toggle
        const filterToggle = document.querySelector('.mobile-filter-toggle');
        const filters = document.querySelector('.filters');

        if (filterToggle && filters) {
            filterToggle.addEventListener('click', function() {
                filters.classList.toggle('active');

                if (filters.classList.contains('active')) {
                    filterToggle.innerHTML = '<i class="fas fa-times"></i> Hide Filters';
                } else {
                    filterToggle.innerHTML = '<i class="fas fa-filter"></i> Show Filters';
                }
            });
        }

        // Sort functionality
        const sortSelect = document.getElementById('sort');

        if (sortSelect) {
            sortSelect.addEventListener('change', function() {
                const products = document.querySelectorAll('.product-card');
                const productsArray = Array.from(products);
                const productGrid = document.querySelector('.product-grid');

                switch(this.value) {
                    case 'price_low':
                        productsArray.sort((a, b) => {
                            const priceA = parseFloat(a.querySelector('.price').innerText.replace('$', ''));
                            const priceB = parseFloat(b.querySelector('.price').innerText.replace('$', ''));
                            return priceA - priceB;
                        });
                        break;
                    case 'price_high':
                        productsArray.sort((a, b) => {
                            const priceA = parseFloat(a.querySelector('.price').innerText.replace('$', ''));
                            const priceB = parseFloat(b.querySelector('.price').innerText.replace('$', ''));
                            return priceB - priceA;
                        });
                        break;
                    case 'name_asc':
                        productsArray.sort((a, b) => {
                            const nameA = a.querySelector('h3').innerText;
                            const nameB = b.querySelector('h3').innerText;
                            return nameA.localeCompare(nameB);
                        });
                        break;
                    case 'name_desc':
                        productsArray.sort((a, b) => {
                            const nameA = a.querySelector('h3').innerText;
                            const nameB = b.querySelector('h3').innerText;
                            return nameB.localeCompare(nameA);
                        });
                        break;
                    default:
                        // Default is newest, no sorting needed
                        break;
                }

                // Clear and re-append sorted products
                productGrid.innerHTML = '';
                productsArray.forEach(product => {
                    productGrid.appendChild(product);
                });
            });
        }
    </script>
</body>
</html>
